# Plan: one registry for every entry

Status: **all phases done** (2026-10-23, see sections 5–13). Versions: phases 0–1 in v0.4.2, phase 2 = v0.4.3, then one patch version per phase. Baseline (v0.4.2): 962 entries, 503 of them partly or wholly implemented by
**670 name checks** (`hasName(st,"…")`, `boosted`, `bOn`, `cOn`, `charNamed`, `recOf`, `blessingOn`) spread over
~20 files and four layers of function wrappers (bc.js, more.js, missed.js, large.js). See `framework-audit.md`.

Goal: everything an entry does is written in **one place** (its registry record). The core code calls fixed hook
points; it never mentions an entry by name. Behaviour does not change.

---

## 1. What the registry looks like

### One record per entry

```js
// build/src/reg/body.js (one file per book, entries in alphabetical order)
REG("Regeneration", {
  turnStart(st, o, x) {              // x = shared context: notes, computed sheet, helpers
    const [pct, turns] = REGEN[o.tier|0];
    x.heal(st, pct, {spread: true});
    x.wearOff(st, "Physical", turns);
  }
});

REG("Packing Heat", {
  send(P, x) {                       // an outgoing roll from the owner
    if (x.isCockViolate && x.stage(P) >= 1) P.sensBonus += x.flag("oppSen");
  }
});

REG("Hold", {                        // a Magic Trait Spell: same record, Spell slot
  spell: { sustained: true, effect: t => ({dis:["EVA"], flags:{noMove:1, holdStr:HOLD[tierIx(t)]}}) },
  afterRoll(st, o, x) { if (x.type === "ESC") x.holdEscape(); }
});
```

The data (modifiers, tiers, toggles, counters, flags) stays in the DB as it is. A record only holds the behaviour
the data can't express.

### Slots

Each slot is one fixed hook point that the core calls. These slots cover everything the current wrappers do:

| Group | Slots | Replaces today |
|---|---|---|
| Sheet | `mods(st,o,x)` → extra modifiers · `dice(st,o,D)` · `caps(st,o,C)` (HP / MR / weight) · `tierGate` | encMods / compute wrappers, engine special cases |
| Every commit | `sync(st,o,x)` | missedSync, largeSync, bcWatch, virginWatch |
| Own rolls | `block` · `preRoll` · `raw` · `damage` (multipliers) · `afterRoll` · `send(P)` | doCombatRoll wrappers, actions.js inline checks, missedSend |
| Being targeted | `chain(p,list)` · `targetPen` · `diceVs` · `reaction` (RX shape) | defenseChain, vsPenalty, fxDiceVs, RX |
| Hits | `landed(A,T,p)` · `damaged(p,part,r)` · `defended(p,k)` | landedHooks, moreDamage, bcDamaged, moreDefended |
| Sensitivity | `sensPre` · `sensPost(total,chart)` · `orgasm` · `ejac(forced)` · `semen(t,hole,A)` | doSensRoll, bcSensPost, bcEjac, bcSemen wrappers |
| Time | `turnStart` · `battleStart` · `battleEnd` · `rest(kind)` · `moved(voluntary)` | moreTurnStart, bc* battle / rest hooks, posChanged |
| Actions | `ability` (current ABIL shape) · `special` (SR shape) · `spell` (SPELL_FX / FX_DEFS shape) · `imbue` | ABIL, SR, SPELL_FX, FX_DEFS, IMBUE |
| Blessings / Curses | `curse` (CURSE shape) · `blessing` (new: trigger + effect, same shape as CURSE) · `manual` (BC_MANUAL) | CURSE, BC_MANUAL, the `bOn` checks in bc.js |
| Interactions | `immune: [names]` · `aura(st,o,other)` (what this entry does to *other* characters) · `boosts: {Entry: {...}}` | IMMUNE_LIST, auraMods, TRAIT_BOOSTS + `boosted()` checks |
| UI | `rollUI` · `rowUI` | moreRollUI, bcRowHTML wrappers |

Two scopes per slot: **own** (fires for the character who has the entry) and **aura** (fires for every *other*
character, e.g. Mana Void halving the MR of those Near, Humility, Chastity). This removes the
`TABS.some(t => hasName(t,"…"))` pattern.

### The dispatcher

```js
const REGS = {};                              // name → record
function REG(name, rec) { REGS[name] = Object.assign({name, order: 0}, rec); }
// owned records, cached on the computed sheet (rebuilt by compute)
C.reg = ownedEntries(st).filter(...).map(([o,e]) => [o, e, REGS[e.n]]).filter(r => r[2]);
function fire(slot, st, ...args)      // every owned record with that slot, in `order`
function fireAura(slot, st, ...args)  // other characters' records with an `aura` slot
function reduce(slot, st, value, ...) // for slots that transform a value (damage, chain, dice)
```

- `boosted()`, `immuneTo()` and `hasName()` stay as **services** the records call. The rule is about where a
  name appears: only in its own record, or as data (an immunity list, a boost key).
- The existing table objects (`ABIL`, `SR`, `SPELL_FX`, `FX_DEFS`, `RX`, `IMBUE`, `CURSE`, `BC_MANUAL`,
  `AP_ONLY`) become **views** generated from the registry, so UI code that reads `ABIL[n]` keeps working
  until it is switched over.

### File layout

```
build/src/reg/core.js        REG, dispatcher, context helpers (x.heal, x.stage, x.flag, …)
build/src/reg/body.js        Body Characteristics
build/src/reg/soul.js        Soul Characteristics
build/src/reg/physical.js    Physical Traits
build/src/reg/magic.js       Magic Traits
build/src/reg/bctrait.js     Blessing / Curse Traits
build/src/reg/blessing.js    Blessings
build/src/reg/curse.js       Curses
```

Shared mechanics that aren't entries (effects engine, holds, positions, clothing, imbue costs, trackers) stay in
their files as services.

---

## 2. Migration order

Each phase is shippable on its own and keeps behaviour identical (checked by the tests in section 3).

| # | Phase | What moves | Risk | Effort |
|---|---|---|---|---|
| 0 | **Test harness** | Seeded RNG, scenario runner, golden snapshots, the name-check counter (section 3) | — | 1 session |
| 1 | **Registry core** | `reg/core.js`; one call to `fire()` at each hook point next to the current wrappers (both run) | Low | 1 session |
| 2 | **Tables → views** | ABIL, SR, SPELL_FX, FX_DEFS, RX, IMBUE, CURSE, BC_MANUAL, AP_ONLY, ADV move into records; the old names become generated views | Low (same code, new home) | 1 session |
| 3 | **Newest layers** | `missed.js` and `large.js` (~110 entries); their wrappers are deleted as each block moves | Low (newest, best tested) | 1 session |
| 4 | **Blessings & Curses** | bc.js: new `blessing` slot, every `bOn` / `cOn` check into its record; add the Curse "Sensitivity" | Medium | 1–2 sessions |
| 5 | **Middle layers** | more.js, extras.js, hooks.js, trackers.js, specials.js special cases | Medium | 2 sessions |
| 6 | **Core inline checks** | the name checks inside doCombatRoll, doSensRoll, sendIncoming, incAccept, compute, endTurn: one hook point at a time | High (central code) | 2–3 sessions |
| 7 | **Boosts** | each `boosted(st,"X")` check becomes `boosts: {X: …}` on the boosted entry's record; TRAIT_BOOSTS becomes a view | Medium | 1 session |
| 8 | **Clean-up** | delete empty wrapper layers and old files; the unimplemented-entries report reads the registry directly; HANDOFF rewritten | Low | ½ session |

About 10–12 sessions in all. Phases 2–5 can be split per book if a session runs long.

**Order inside a phase:** move the entries one hook point at a time, not one file at a time. When every user of a
wrapper has moved, delete the wrapper in the same step. That keeps exactly one path per hook point, so there's no
double application.

**Wrapper order matters.** Today the order in which the layers wrap a function decides which effect applies first
(e.g. damage halving before or after a cap). The dispatcher's `order` field records that explicitly. Phase 1 writes
down the current order of each wrapped function (bc → more → missed → large) and gives the records the matching
`order` values.

---

## 3. How to test it

### 3.1 Golden snapshots (the main safety net)

- **Seeded dice:** `rnd()` and `Math.random` replaced by a seeded generator in test mode, so every run rolls the
  same numbers.
- **Scenario runner:** `build/test/runner.html` loads the built sheet in an iframe, runs scenarios, and compares the
  results with `build/test/golden.json`. It is run in the preview browser (no extra tools needed) and prints a diff.
- **One generic scenario per entry (962):** give the entry to an attacker and, separately, to a defender. Then play a
  fixed script that touches every hook point:
  - start battle, then each Offensive Roll type in both directions, Accept, then contest with each defence;
  - Sensitivity Rolls in each zone, a forced Orgasm and a Forced Ejaculation, Semen in each hole;
  - a move Near and Far, three End Turns, use of the entry's ability / special roll / Spell if it has one;
  - Short Rest, Long Rest, End Battle.
- **What is snapshotted:** after each step, a normalised copy of both characters (HP, Mana, PP, SP, AP, statuses,
  effects, pen / bound, trackers, computed totals, prompts, log titles), with ids and timestamps stripped.
- **Hand-written scenarios (~150)** for entries the generic script can't reach: ones that need a setup
  (Polemokinesis imbues, holds, pregnancy, clothing styles, extra tabs, Rests with Curses, boosts with their source).
- **Recording:** the goldens are recorded **once, before phase 1**, from v0.4.2. Every phase must reproduce them
  exactly. A diff is either a bug, or a deliberate fix that is listed and re-recorded.

### 3.2 The name-check counter

`build/test/audit.js` (from the framework audit) runs with every build:
- counts name checks outside `reg/` files: **670 today → must be 0 at the end, and may never go up**;
- lists entries whose behaviour is split between a record and outside code;
- fails the build if an entry name appears in two records.

### 3.3 Per-phase checklist

1. Build passes, plus the syntax check.
2. All golden scenarios match (or every diff is explained).
3. The name-check count went down by the expected amount.
4. A manual pass in the browser: every section rendered, an encounter with two tabs played for a few turns, no
   console errors.
5. HANDOFF updated with which hook points are on the registry.

---

## 4. Open decisions

- **Version:** behaviour doesn't change, so a patch number per phase, or one **v0.5.0** when the refactor is done.
  (No bump until you say so.)
- **Tool Conversion and Cryptoid Symbiont:** build them directly as registry records after phase 1, rather than as
  one more wrapper layer.
- **Generated scenarios:** whether 962 × 2 generic runs is fast enough in the browser (estimate: under a minute).
  If not, they run per book.

---

## 5. Phase 0 results

- `build/test/`: `serve.js` (test server, preview config "tests", port 8766), `harness.js`, `runner.html`, `golden.json`, `baseline.html`, `audit.js` + `audit-baseline.json`.
- The only change to the app: `uid()` and `rnd()` take test-only seeded sources when the harness sets them. Nothing changes otherwise.
- **Scenarios:** 1935 = 962 entries × 2 (owner as Heroine and as Enemy) + 11 setups. All run in ~45 s with rendering off. 0 errors at v0.4.2.
- **Checks:** a second run matches 1935 / 1935. Three deliberate changes (Relentless +6, Regeneration 6%, Suffer +11) were each caught, and Inspect showed the exact values that moved. The first try missed Relentless because the script never attacked the same part twice, so the script now attacks twice in a row. Expect more gaps like that: add a setup when an entry needs one.
- **Fewer hand-written scenarios than planned:** the generic script uses each entry's own ability, special roll, Spell or reaction, so 11 setups cover what it can't reach for now. Add more as each phase touches an area.
- **Name-check count:** 748 (it also counts `bcRec`, `curseAct`, `condOn`, `fxNamed` and `recOf` / `recsOf` when the name is an entry; the earlier 670 left those out). `build.js` stops if it rises.

## 6. Phase 1 results

- `build/src/reg/core.js` (after large.js in the build) plus empty book files `reg/body.js`, `soul.js`, `physical.js`, `magic.js`, `bctrait.js`, `blessing.js`, `curse.js`. No records yet, so nothing changes: goldens match 1935 / 1935.
- **`REG(name, record)`** checks for duplicates, unknown slot names (typos) and names that aren't an entry. **Dispatcher:** `regFire` (all answers), `regFirst`, `regReduce` (pass a value through), `regAura` (other characters' records aimed at a target). The owned-record list is cached per character until its entries change. A record that throws is logged and skipped (the test harness counts it as a step error).
- **31 hook points**, each wrapping the outermost version of the function. The full list with arguments is the comment at the top of `core.js`. Changes from section 1: `damage` is `damageX` (the existing Elemental multiplier point); `diceVs` is split into `diceVs` (attacker) and `diceAgainst` (target); hits add `struck` (the target side of `landed`) and `missed` (the attacker side of `defended`); Semen adds `cum` (the giver's side); `sensResult` is the per-result hook (Orgasm, Ejaculation checks); `aura` currently covers `mods`, `turnStart` and `moved`. The table slots (ability, special, spell, imbue, curse, blessing, manual, reaction, boosts) are reserved for phase 2.
- **Order:** the wrapper layers run inner → outer as bc → more → missed → large, and the core is outermost. A migrated record keeps its layer as `order` (bc 10, more 20, missed 30, large 40). "After" slots run ascending and "before" slots (`block`, `preRoll`, `sensPre`) descending, matching how wrapper code runs before and after the inner call. Migrating outermost layers first (large, missed, then more, then bc) keeps the order effects apply in.
- **Checked:** a probe record on every slot fired at all 31 hook points (most during normal scenarios; `defended`, `missed`, `semen`, `cum`, the UI slots and `aura.moved` by direct calls), return values arrive where they should, "before" / "after" order is right, and the warnings work. The sheet loads and renders with no console errors.

Current wrapper chains (inner → outer), for reference when migrating:

| Function | Layers |
|---|---|
| addEffect | more → missed → large |
| apCostOf, bcRest, statusHook | more → large |
| bcBattleStart, commit, compute, doCombatRoll, encMods, landedHooks, manaAdj, moreRollUI, moreTurnStart, sendIncoming | missed → large |
| bcSensPost, moreBattleEnd | more → missed → large |
| moreDamage | more → missed → missed → large → large |
| hitCloth | missed → missed → large |
| moveTo | bc → more → more → missed |
| placeIn | bc → missed |
| rollTargets | more → more |
| addStatus, auraMods, bcEjac, bcRowHTML, bcSemen, curseAct, defenseChain, doSensRoll, fxDiceVs, moreDefended, useAbility, vsPenalty | missed |
| bcPenalty | more |
| curseLanded, fxRaw, itemEPD, posChanged, ENC_ACT.incAccept | large |

## 7. Phase 2 results (v0.4.3)

- **388 table definitions moved into 359 records** in `build/src/reg/<book>.js`, verbatim: ABIL 143 → `ability`, SR 48 → `special`, SPELL_FX 51 → `spell`, FX_DEFS 45 → `spellFx`, RX 18 → `reaction`, CURSE 31 → `curse`, BC_MANUAL 29 → `manual`, AP_ONLY 14 → `apOnly`, ADV 9 → `advanced`. Done with a scanner-based mover script (strings, templates, regex and function bodies understood), not by hand.
- Three loops that created entries were turned into plain definitions first: the tentacle AP_ONLY entries, the Blacksmith / Handyman / Tinker aliases of `ABIL.Repair`, and the bond Spells (now `bondSpell(k)` in more.js).
- **Views:** `reg/views.js` (after the book files) fills the old tables from the records, then runs the code queued with `regLate(fn)` (defined at the top of engine.js), then puts each table back in its pre-move key order (`REG_ORDER`, so UI lists keep their order) and copies wrapped values back into the records.
- **16 load-time statements deferred with `regLate`:** the wrappers and loops that changed table entries while the page loaded (immunity wrappers in missed.js, Striking Pose, Stealth, Charm, Pitiable, Magic Mimicry, Alt-Ego, Modification Tentacle, Shadow Puppetry, Suckle, Soul Rend, Sticky Fingers, the Seductive Whisper and Soteriology loops). They still live in their old files; phases 3–5 move them into the records' hook slots.
- **Stayed in their tables (not entry names):** `ABIL.Repair` (the shared repair ability) and `RX["Second Evasion (Draconic)"]`. **IMBUE stays a service table:** its keys are Polemokinesis imbue options, not entries.
- **Checks:** goldens 1935 / 1935. The new table check (runner: *Compare tables with baseline*, every entry's key order and function source after all wrappers) shows **402 of 417 identical**. The other 15 differ in one known way: the immunity loops in missed.js now also wrap the 14 abilities and White Projectile that missed.js and large.js define later (before, the loops ran too early to see them). None of those names is on an immunity list, so the added check never fires. The sheet renders with no console errors.
- **Name checks:** 748 → 585 (the moved code is in reg/, which the counter skips).

## 8. Phase 3 results (v0.4.4)

- **missed.js and large.js are gone.** Their ~60 entries' code is now in records (`order` 30 = missed, 40 = large), with each entry's helpers directly above its record; helpers several records share are in `reg/shared.js`.
- **New in the core:**
  - `always` slots (rec.always.<slot>(st, …)) for code that ran for every character: per-battle counters everyone keeps (Inner Confidence's hit count, Relentless, Prepared AP…), flags carried by a roll (toxins, Double Cocked, Perverse Sacrifice), effects an entry left on someone (Heated, Hold, Squeezed, Slumber), the Entity tab, Temperance / Kindness / Charity. Making these owner-only would have changed state in every golden.
  - Per-slot order overrides (`orders`), so large.js's turn-start sequence (toxins → own → Patience → Diligence → Entity) is kept.
  - About 25 more hook points: effectIn, statusAdded, apCost, manaCost, targeted, accepted, curseInflicted, rollAborted, clothHitBefore / clothHit / clothHitBy, itemEPD, peApplied, tempMods, itemWeightX, noSacrifice, immuneTest, bcRowUI, commit (once per commit), plus the named-table hooks onSpecial / onSpecialUsed / onSpell and the prompts / trackers slots.
  - The services the rest of the code calls now live in the core: immuneTo (records' immune lists and immuneTest), elemDmgX, tierGate, tempMods, greedX, noSacrifice, posChanged, peAddHook, peBlock, evaHalfOf; and the moveTo / placeIn wrappers that detect position changes.
- **Checks:**
  - Goldens 1935 / 1935. Two (Suckle, owner as Heroine / Enemy) were re-recorded: the old Concentrated Mana Milk wrapper read the caster's Milk Jug counter on every Suckle, creating an empty tracker object as a side effect. The runner now only re-records a filtered set with a written reason, stored in golden.json, and keeps the original baseline build.
  - The goldens give each entry to one character, so I added `TEST.custom(id, script)` and ran 13 interaction scripts (Packing Heat + Girthy, Kindness with allies, Temperance across tabs, Extra Tight Pussy + Squeeze on the Cock owner's roll, Prepared + Supercharged moves, Diligence, the Entity's life cycle, Immortal knock-outs and Soul Rend, Envy, Suckle + Concentrated Mana Milk, Mana Void / Patience / Humility, Double Cocked + Toxicology, and a mixed set). All identical to the v0.4.2 baseline, and spot checks confirmed they exercise the features.
  - Tables: 399 of 417 identical. The 18 that differ: the 15 from phase 2, Through The Veil's new `skipOnce`, and Soul Rend / Sticky Fingers / Suckle, which are now wrapped by the registry's named hooks instead of the old wrappers.
  - No warnings when the records load; the sheet renders with no console errors.
- **Known small differences** (only when several of these entries meet on one character, so no golden covers them): at the same order, calls now run always → own → aura and then by the order of entries on the sheet, so text in a combined log line can come out in a different order, and with two blocking entries a different one may be reported. Mana Void, Humility and Patience still apply once in total when several characters have them.
- **Name checks:** 585 → 494.

## 9. Phase 4 results (v0.4.5)

- **bc.js holds no entry code.** 77 records (order 10) in blessing.js, curse.js and bctrait.js, plus Determined (physical.js) and Perfect Miasma Control (soul.js). bc.js keeps the shared rules (bOn / cOn and the Earth-bound rule, curseResist / curseAct, Curse Rolls landing, the row controls) and the hook points the rest of the app calls; each now fires its slot.
- **New slots:** hurt (after damage), defeat (kept standing at 0 HP, first answer wins), bound, lewdHit, sensSkip, sensMid, sensPenalty, ejacMana, semenGuard, pp100 / ppChange, restBlock, moveBlock, curseLimit, cursePlaced, resistCurse, curseControls, rowStatus, manualUI; `blessing: {on}` for trigger buttons, `actions` for buttons a record draws, the named hook `onSpellCast` (Soteriology on the helpful Spells). bcSemen and bcEjac are core functions now.
- **Two layers at one hook point:** more.js still wraps bcSensPost, bcPenalty, bcRest and (through placeIn / moveTo) the move code, so bc.js fires only order < 20 there (`slot@in`) and the core fires the rest where the outer layers ran (`slot@out`). Phase 5 can merge them once more.js is records.
- **Order:** where several bc entries answer one call, the old code had a fixed sequence (e.g. Continence first on Semen, Futafication and Vibrancy interleaved per 100 PP). Records use `orders` 10.01, 10.02 … to keep it, so rolls come in the same order as before.
- **Earth-bound:** the core's list of a character's records leaves out Blessings other than Ascension while Ascension is at 600+ PP (without Silver / Tarnished Heart), as bOn did.
- **Added:** the Curse "Sensitivity" now has a record; its Forced Activation prompts the triggering character to pick a Sensitivity Roll. Its always-on part stays in the data flags.
- **Checks:**
  - Goldens 1935 / 1935. One differed on the way (Lactation now fired before Glow at battle start), fixed with an order.
  - 11 interaction scripts, kept in `build/test/interactions.js` and run by the runner's new "Run interaction scripts" button: defeat chain (Determined, Entwined Lives, Steadfast, Tithe, Suffer), rolls sent (Gaze, Messaging, Lofty, Stringent, Slave, Solomon, Sacred Ground), Semen with 11 entries, Sensitivity with 11, turn start with 25, rests with 11, Curse Rolls (Twice Blight, Infection), PP thresholds, the Blessing buttons and row HTML, helpful Spells (Soteriology, Tribute), Camaraderie and Earth-bound. All identical to the v0.4.2 baseline.
  - Tables: 26 of 417 differ: the 18 from phase 3, Stealth (the Glow / Gleam check moved into its record), Cleanse / Purify / Purge / Revive / Detox (wrapped by the registry's named hooks instead of a bc.js wrapper), CURSE key order and the new Sensitivity.
  - No warnings when the records load; the sheet renders with no console errors.
- **Known small differences** (text order only): the All-Mother "re-enabled" note now comes first among the turn-start notes, and "Semen Addiction: Oral Sensitivity" comes after Fatal Obsession's note.
- **Name checks:** 494 → 355.

## 10. Phase 5 results (v0.4.6)

- **Moved:** about 110 entries from more.js, extras.js, hooks.js, trackers.js and specials.js. hooks.js, extras.js, trackers.js and specials.js have no entry name checks left; more.js keeps the shared mechanics (bonds, companions on a move, effects resisted once per turn, Event Horizon, item / tech helpers) and one boost reaction (Second Evasion, phase 7).
- **Dispatch points:** the functions the rest of the code calls keep their names and now fire slots: auraMods → groupMods, actGate → actGate, auraTurnStart / moreTurnStart / boostTurnStart / rewindSnap → turnStart bands, sensOrgasm → orgasm, releaseBlocked → releaseBlock / releaseBlockBy, trueApply → trueOut / trueImmune / trueParts / trueTaken / trueDealt, grantX → grantOut / grantIn, whisperAt → voiced, invigCum → ejacGift, quickShotRow → ejacRow, mjFeed → feedMilk, landedHooks → landed / struck, carryAP, loanCover → coverMana, talismanBlock / talismanUse → castBlock / castPaid, cumHook → cumInto, trapCheck → trapImmune, chargeApply → chargeCushion / chargeAttract, copyTrait → copyKeep, trackersHTML → trackerUI, imbueMax / activeImbues / imbueCostOf → imbueMax / imbueCap / imbueCost, rxButtons, statusHook → statusAdded (now a core function), sizeShift → resizeKeep, moveCompanions → companions, techTurnStart → techPart, virginWatch → corrWatch, moreDamage → damaged bands + animaHit, moreAfterHit → afterHit, moreDefended → defended / missed bands, lactForce → lactResist, rollTargets → targets, castExtras → castCost, the moveTo / bcSensPost wrappers → moveStop / sensSkipPost, boostScale → each entry's own boostScale.
- **Bands:** a slot called from several places in a row fires only an order band at each place (`slot@a-b`), so the old sequence holds without merging the call sites yet: turnStart 0–10 auraTurnStart, 10–20 bcTurnStart, 20–21 moreTurnStart (four sub-bands around its shared steps), 21–45 the core after it, 50–60 boostTurnStart, 60–70 rewindSnap; damaged / defended / missed 20–30 inside moreDamage / moreDefended and 30 and up in the core. `@in` is now the band 10–20. REG warns when a record with hook slots has no order.
- **Boost wrappers** from more.js went into the boosted entry's own record (Charm, Pitiable, Magic Mimicry, Alt-Ego, Modification Tentacle, Spaced Out, Fatal Obsession, Heroine Fallen, Prehensile Tail, Dribble, Roper Tentacle, the per-turn Demonic / Holy effects). Their `boosted()` checks stay for phase 7.
- **New named hook** `onAbility` on ABIL uses (function, or {before, after}); Too Cool For You and My Turn Loser on Striking Pose, Seductive Whisper on Come Get Some / Hypnagogic Tone.
- **Checks:**
  - Goldens 1935 / 1935.
  - 21 interaction scripts identical to the v0.4.2 baseline, 10 of them new: landed traits (11 attacker Traits + Violence), group mods, act gates (On Your Knees, Heartthrob, Fatigue), turn-start bands (Lust Aura, Brilliant Light, Autosuggestion, Lift, Blue Blood, Confused, Item Reconstruction ×2, Grower, Mana Loan, Adrenaline Rush, Rewind), the damage chain (Shadowless, Sacratus, Hostage, Detachable, Mana Cocoon, Deliberation, Disorientation, Shockwave, Reroute), True Damage (Truly Heavenly, Justice Enforcer, Godly, Adaptive Immunity, Too Cool For You, My Turn Loser), casting values, Cum and Milk, misc hooks (statuses, rx buttons, trackers card, traps, Polarity Charges, Seductive Whisper), and boosts (Demonic, Holy, Singular Type, Draconic Spirit, Prodigious Spellslinger, Maternal Symbol).
  - Tables: 30 of 417 differ: the 26 from phase 4, plus Striking Pose / Come Get Some / Hypnagogic Tone (wrapped by onAbility) and IMBUE Sacratus (its target check is a data list now). The fingerprint only sees the outermost wrapper of an ability, so records whose own code changed under the immunity wrapper (Charm, Pitiable …) don't show; the goldens and the boosts script cover them.
  - No warnings when the records load; the sheet renders with no console errors.
- **Known small differences:** the two On Your Knees entries are separate records, so a target with both (and Both genitals) asks for two Resistance Rolls instead of one; with several targets the gates now go entry by entry instead of target by target. The Pestilence prompt needs the Trait as well as its effect.
- **Name checks:** 355 → 200.

## 11. Phase 6 results (v0.4.7)

- **No entry name checks left in the core files** except `boosted()` (phase 7): actions.js, encounter.js, ui.js, engine.js, abilities.js, clothaccess.js, reactions.js, effects.js, ui_items.js, forms.js, advanced.js, layout.js, locks.js, positions.js and bc.js.
- **Rules** (new): many checks were one switch inside a shared formula (bound arms halve AP unless Multi-Armed; equipping costs 1 AP less with Quick Draw; refractory +1 with Extra Thick Load). Pulling each into a slot would have split those formulas into many tiny hook points, so the record declares the switch instead: `REG("Multi-Armed",{rules:{multiArmed:1}})`, and the shared code reads `regRule(st,"multiArmed")`. regRule looks at the same entries hasName does (Characteristics and Traits, granted ones and those on items), so behaviour is unchanged; the keys say what the rule does, not who has it. 100 records carry rules.
- **Slots** where an entry's behaviour is a piece of its own: extraWeight, barrierDice, senDice, animaPay, chargeSpell, clothRepaired, offensiveRoll, lactManaFree, defeatGuard, blessingDrop, plus existing slots (diceVs for Inferiority, peApplied for Professional Dom / Massage Therapist / Rough Master, send / targeted in two bands of sendIncoming for the attacker's Tentacle and Lewd modifiers and Attractive Privilege).
- **Checks:**
  - Goldens 1935 / 1935.
  - 25 interaction scripts identical to the v0.4.2 baseline, 4 of them new: body rules (16 compute-time entries on one sheet, bound limbs and heads at 0 HP), action rules (31 entries: equipment, Feint / Charge / Assassin rolls, Escape with Tight Hold / Escape Artist, statuses, ejaculation, rests), incoming rules (22 attacker entries and 8 on the target: the send bands, Accept-time rules, defences, a restraint), misc rules (UI-side switches, cloth repair with Liberated, Inferiority dice).
  - Tables: unchanged from phase 5 (30 of 417, all explained).
  - No warnings when the records load; the sheet renders with no console errors.
- **Noticed (pre-existing, same in v0.4.2):** a Liberated repair logs its line twice (curseAct logs it and the repair logs it again); Inferiority's dice note says d10 while the roll uses the lowered die (fxDiceVs runs twice for the note).
- **Name checks:** 200 → 27, all `boosted()`.

## 12. Phase 7 results (v0.4.8)

- **TRAIT_BOOSTS is a view** built by reg/views.js from the `boosts` slot of each source entry's record, in the old key order. The data (grant, ban / banUnless, on, label, the boosted Traits and their texts) moved as it was; Singular Type, which isn't an entry name, is on the Tentacle Abomination record with `boostKey: "Singular Type"` so saved boost toggles keep their key.
- **BOOST_TIER is a view** of the `boostTier` slot on Anti-Magic, Incorporeal, Purify, Stillness, Exonerate and Heart Knight.
- **boostRules / regBoost:** the `boosted(st,"X")` checks in the core files (doCombatRoll damage, Escape, traps, Rapid Fire, Mana Aura, Composure, Generous Split, AP and Mana costs, Social Faux Pas, Girthy Tentacle, Second Evasion) became `regBoost(st,key)`; the key is declared on X's record (`boostRules: {hornDouble: 1}`) and regBoost returns the boost source like boosted() did. A rule value can be a function for an extra condition (One-Man Army also needs Self-Sufficiency; Malignus counts only when taken again). Records keep calling `boosted()` for their own boosts.
- **Checks:** goldens 1935 / 1935; 26 interaction scripts identical to the v0.4.2 baseline (new: boost rules — Draconic Spirit, Prodigious Spellslinger, Demonic, Singular Type and Holy with 24 boosted Traits); tables: TRAIT_BOOSTS and BOOST_TIER identical, 31 of 417 differ (the 30 from phase 6 and the Second Evasion reaction, whose check uses regBoost); no load warnings or console errors.
- **Name checks outside reg/: 27 → 0.**

## 13. Phase 8 results (v0.4.9)

- **IMBUE is a view** of the `imbue` slot (the twelve Elemental imbues, Sacratus, Malignus), so no table slot is reserved any more. The table comparison shows IMBUE identical apart from Sacratus (its target check became a data list in phase 5).
- **Removed:** the `regLate` queue (nothing used it after phase 5), and eight wrappers in core.js that only fired a slot right after the wrapped function returned: bcRest, bcBattleStart, bcRowHTML, moreTurnStart, moreDamage, moreDefended, moreRollUI, moreBattleEnd now fire those slots themselves. Wrappers that still sit between two layers (bcSensPost with Spaced Out, addEffect with Share, sendIncoming, curseLanded, the roll and compute hooks) stay.
- **Name-check counter:** it now matches any first argument, which found four checks the old pattern missed (`hasName(T[0],"Ankle Biter")`, Divine Healer's full revive, Hibernate's boost, Milker Tentacle's boost); they became rules / boost rules. Count: 0.
- **The unimplemented-entries report reads the registry:** `build/test/report.js` (run by build.js) counts an entry as done when it has effects in its data, its own record, or code in another record that handles it, and lists separately the entries still handled by name in the shared code. The hand-written notes (plans, work groups, partial cases, boost texts) are in `report-notes.json`. Result: 937 of 962 entries have behaviour, 25 left (the 23 of the hand check plus Passed and Heal, which the old check counted because those words appear as unrelated labels), 10 handled by name in shared code, 8 boost texts open.
- **HANDOFF.md rewritten** around the registry (how to add behaviour, slots, orders and bands, rules, tests).
- **Checks:** goldens 1935 / 1935; 26 interaction scripts identical to the v0.4.2 baseline; tables 31 / 417 differ (unchanged, all explained); no load warnings or console errors.

## 14. What the plan changed, in one paragraph

Before: 670 name checks over ~20 files and four wrapper layers (bc.js, more.js, missed.js, large.js), where the order of wrapping decided which rule applied first. After: 646 registry records hold every entry's behaviour (or its data does); the shared code calls ~110 documented hook points and names no entry; the old wrapping order is kept as explicit `order` values and call-site bands; behaviour is unchanged, checked by 1935 golden scenarios and 26 multi-entry scripts against the v0.4.2 build. Known small differences are listed per phase above (text order in a few combined log lines, On Your Knees with both entries on one target, the Pestilence prompt needing the Trait).
