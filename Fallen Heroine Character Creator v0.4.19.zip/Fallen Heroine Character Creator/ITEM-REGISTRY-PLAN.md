# Plan: Items in the registry

Status: **all phases done** (2026-10-23, v0.4.11–v0.4.18; decisions in section 6, results per phase from section 7). What each Item still lacks is in the unimplemented-entries report. Follows REGISTRY-PLAN.md, which moved every
Characteristic, Trait, Blessing and Curse into `build/src/reg/` but left Items out.

Goal: an Item's behaviour is written in its own registry record, like every other entry. Equipped Items (and Pacification
Equipment placed on someone) take part in the same hook points, show up in the coverage report, and respect the
automation switches. Then the Items whose rules matter most in play get implemented, group by group.

---

## 1. Where Items stand today

- **224 Items** in 6 groups. Only **~42** have any behaviour on the sheet (data effects or code that names them):

  | Group | Items | With behaviour | Notes |
  |---|---|---|---|
  | Warfare | 2 | 2 | Weapon User (EPD, weapon picker), Shield Bearer (Shield roll) |
  | Narrative | 2 | 2 | Something of Note, Challenge Badge (tiers) |
  | Apparel | 18 | 13 | mostly tier / modifier data; Mask, Scarf, Cape, Wristwatch, Fake Nails etc. are text only |
  | Expendable | 13 | 6 | tiers exist for Consumables, Pills, Explosives, Ammo; using them does nothing |
  | Pacification Equipment | 58 | 14 | the generic "apply to a body part" system covers Roll Strength, OD, insertion and max stage for all of them; their own effects (gags, collars, vibrators …) are mostly text only |
  | Utility | 131 | 5 | 59 ordinary / supernatural / high-tech tools, plus the 72 Seals of Ars Goetia |

- **How the existing behaviour works:**
  - *Data:* `itemProps` reads weight, OD, DN, held / wearable / insertable from the meta and tiers; compute adds an equipped
    Item's modifiers (engine.js, `kind==="item"`); carried weight skips dropped and stored Items.
  - *Item modifications* (itemmods.js): `modEffects` and `modVirtuals`. Modifications that grant a Trait (Enhanced Armory,
    Malice / Miracle Infused, Sanctified, Profane) create virtual entries that **do** go through the registry.
  - *Pacification Equipment:* `ST.peApplied` on the wearer (advanced2.js `peMeta` / `peActive`, actions.js `peAdd` / `peRm`
    / `peEscape`).
  - *Name checks:* about 19 Item names appear in shared code (Weapon User, Shield Bearer, Something of Note, Ball Gag,
    Blindfold, Tape, Zip Tie …).
- **What leaves them out:** `regOwned` skips `kind==="item"`, `REG()` warns for any name outside
  `REG_BOOKS` (no "Item"), `hasName` / `regRule` / `regBoost` never look at Items, and the report, the golden scenarios
  and the name-check counter only cover the other seven books. So the automation switches and "by hand" don't reach them.
- **Good news:** no Item name clashes with an entry in another book, and no two Items share a name, so records can stay
  keyed by name.

---

## 2. Design

### 2.1 Owners: when does an Item's record run?

An Item differs from a Trait in three ways: there can be **several copies**, it has **states**, and some Items act on
**someone other than the owner**.

| State | Who it acts for | Runs which calls |
|---|---|---|
| **Equipped** (`eq`, not dropped, not stored, not off by Henshin `formOnly`) | the holder | all of the record's own slots, once **per copy** |
| **Carried** (not equipped) | the holder | only slots marked `carried` (rare: Extra Storage, Hyperspace Cube) |
| **Placed on someone** (Pacification Equipment in `peApplied`) | the wearer, with the placer as `by` | the record's `applied` slots |
| **Broken** (OD 0, where the rule says it stops working) | — | none, unless the record says otherwise |

Changes in reg/core.js:
- `regOwned` gains Item owners: one row per equipped copy (`[o, e, R]`, no de-duplication by name for Items), with the
  state above. `regSig` already includes `eq` / `dropped` / mods; it adds `stored`, `formOnly`, OD-zero and `peApplied`.
- `REG_BOOKS` gets `"Item"`.
- A new call kind for applied Items: `R.applied[slot](wearer, r, placer, …)`, gathered in `regCalls` like `aura`.
- `regRule` / `regBoost` also read equipped Items, so a rule like "Mask: Oral stays Covered" is a `rules` flag.
- New helpers in reg/shared.js: `hasItem(st, n)` (equipped), `itemCount(st, n)` (Roller Skates "+2 per skate"),
  `itemsNamed(st, n)`. `hasName` keeps meaning Characteristics and Traits, so nothing that uses it changes.

### 2.2 Record shape

```js
REG("Lube", {
  use: {cost: {AP: 1}, consume: 1, target: "self|ally|opp",       // Active Items: Use button, then qty / uses / OD go down
        run(st, o, i) { … return "log text"; }},
  applied: {mods(wearer, r) { return [["VIO", 10 * r.stacks, "Lube"]]; }}
});
REG("Ball Gag", {
  applied: {targets(wearer, r, P) { if (P.type === "VIO" && P.zone === "O") return "Ball Gag: Oral is blocked"; }}
});
REG("Roller Skates", {
  mods(st, o) { return [["EVA", 2, "Roller Skates"]]; }            // per copy, so two skates give +4
});
REG("Spirit Stick", {
  dropped(st, o) { addEffect(st, {name: "Spirit Stick dropped", mods: {RES: -20}, turns: 2}); }
});
```

New slots (everything else reuses the existing ones):
- `use`: an Active Item's action. Becomes a view like ABIL, shown as a **Use** button in the Combat Dashboard's Items card
  and the Abilities card. It handles cost, uses / quantity / OD, once-per limits, and the "by hand" fallback (log only).
- `equip` / `unequip` / `dropped`: state changes (Spirit Stick, Cape grabbed, Jet Boots needing all legs).
- `applied.*`: Pacification Equipment effects on the wearer (mods, turnStart, actGate, targets, sensRoll, escape).
- `itemUI`: per-Item controls on its card and in the Items widget (Visor mode, Remote pairing, Special Key, Thermos contents).
- Item rolls (Explosive Crash, Milk Rifle, Leather Bullwhip, R.O.C.K.E.T, T.I.E.D.U.P) use the existing `special` slot;
  `curSR` / `ownedSR` learn about equipped Items.

### 2.3 Automation

- "By hand" moves onto the Item cards (section 4) and the Items widget: `o.manual` is skipped in `regOwned` the same way.
- The Trait automation switches apply automatically (they are checked in `regCalls`). The settings group is renamed
  "Entry automation" and its text mentions Items.

---

## 3. Report coverage and tests

- **Report** (`build/test/report.js`): add `"Item"` to `BOOKS`; Items count as done when they have data effects, their own
  record, or code in another record that names them. Pacification Equipment counts the generic apply system as *partial*
  (Roll Strength / insertion work, own effects missing). Expected starting point: ~42 of 224 done, 14 PE partial.
  The headline becomes "N / 1186 entries".
- **Goldens** (`harness.js`): add Items to `ENTRIES` with a generic Item script: give it, equip it, roll each Offensive
  type both ways, use it if it has a `use`, place it (Pacification Equipment) on the opponent, two End Turns, unequip,
  drop. That adds about 448 scenarios (≈ +15 s per run). **Record them once from v0.4.10 before phase 1**, so phase 1 can
  prove the move changes nothing.
- **Name-check counter** (`audit.js`): count Item names too (≈19 today → 0 after phase 1, never up).
- **Rules check** (`rules.js`): one assertion per Item implemented in phases 2–6, taken from its rule text, e.g.
  "Lube: +10 Violate per application, up to 3", "Ball Gag: no Oral Violate while worn".
- **Interaction scripts:** add one per phase for multi-Item cases (Vibrator + Remote, Special Key + restraint,
  S.P.L.U.R's three parts, Seal + Otherworldly Entity).
- Per the check rule: each phase ends with the full check, and behaviour changes are re-recorded with a reason.

---

## 4. Which Items first

Ranked by how often they come up in a fight and how much of the rule the sheet can apply:

1. **Pacification Equipment (58)**, the genre's core and already half-wired through `peApplied`. Most effects fit
   existing slots:
   - *Ointments* (Lube, Aphrodisiac / Sedative / Brainwash Oil): stacking roll and Sensitivity modifiers.
   - *Gags* (Ball, Ring, Dildo, Strap-On, Funnel, Bridle, Tentacle): block or allow Oral actions, disable Struggle,
     per-turn Violate.
   - *Collars* (Obedience, Shock + Remote, Victim, Bell): statuses while worn, remote-triggered damage.
   - *Vibrators* (+ Remote pairing): per-turn Sensitivity Rolls while on.
   - *Impact* (Paddle, Cane, Floggers, Bullwhip): roll bonuses and penalties, forced Sensitivity Rolls (some already have toggles).
   - *Restraints* (Rope, Chains, Glue, Net, Bodysack, Special Key …): the binding works; add roll penalties, limb counts,
     key locking.
   - *Dildos, Onaholes, Anal Toys, Headwear*: insertion effects, Curses (Cursed Dildo), statuses.
2. **Expendables (13)**: the `use` slot with consumption. Consumables and Pills (tier tables), the medical supplies
   (remove or limit Bleed, Broken, Mana Burn, Flushed, Frigid …), Explosive Crash (Attack special roll, explodes when
   the carrier is hit), Special Ammo (needs a ranged weapon; the ammo tracker exists).
3. **Apparel (18)**: finish the passives. Mask / Pasties (stay Covered), Scarf (no Frigid), Wristwatch (Stop
   immunity), Cape, Fake Nails (+5 to the opponent's Sensitivity on hand Lewd), Gloves, Socks, Footwear, Hats and
   Eyewear tier effects, Enchanted Jewelry and Piercings (Mana store).
4. **Combat Utility (~25 of the 59 tools)**:
   - *Reactions and Spell tools:* Mirror (reflects Spells), Iron Bell, Unrefined Gemstone, Cross, Flashlight, Spiritual Object.
   - *Sustained Spell helpers:* Banner, Foam Finger, Pom Pom, Spirit Stick.
   - *Movement:* Roller Skates, Kick Scooter, Skateboard, Jetpack, Jet Boots, Gravity Drive, Magnetic Rise, AR Visor modes.
   - *Area effects:* Laser Pointer, Professional Camera, EMP Ray.
   - *Rolls:* T.I.E.D.U.P, R.O.C.K.E.T.
   - *The milk set:* Suction Cups, Pressure Tank, Milk Rifle, S.P.L.U.R, D.R.A.I.N (needs Lactation tracking).

   The rest (Cellphone, Sewing Kit, repair tools, Audio Recorder, Thoth Tarot, Grimoire, Hyperspace Cube …) are mostly
   narrative or bookkeeping. They get a short `note` and stay "rule text" unless asked for.
5. **Seals of Ars Goetia (72)**: each Seal gives a summoned Demon's Authority. They depend on Otherworldly Entity's
   summoning (implemented as a large one-off) and Solomon's random Seal. One table-driven record generator, with only
   the combat-relevant Authorities automated. Last, because most are narrative and all need the summon state.

---

## 5. Phases

| # | Phase | What happens | Behaviour change | Effort |
|---|---|---|---|---|
| 0 | **Tests first** | Items in the harness, the report and the name-check counter; goldens recorded from v0.4.10 | none | 1 session |
| 1 | **Item owners** | §2.1 / §2.2 core: Item owners per copy, `applied` kind, `use` / `equip` / `dropped` / `itemUI` slots, `hasItem`, `regRule` / `regBoost` on Items, "by hand" on Item cards; the ~19 name checks move into records | none (goldens must match) | 1–2 sessions |
| 2 | **Pacification Equipment** | the 58 PE entries, by sub-group (Ointments, Gags, Collars, Vibrators + Remote, Impact, Restraints + Key, the rest) | yes, new goldens and rules checks | 2–3 sessions |
| 3 | **Expendables** | `use` with consumption; Consumables, Pills, medical supplies, Explosives, Special Ammo | yes | 1 session |
| 4 | **Apparel** | the passive effects in §4.3 | yes | 1 session |
| 5 | **Combat Utility** | the ~25 tools in §4.4; notes for the narrative ones | yes | 2 sessions |
| 6 | **Seals** | the Seal record generator with Otherworldly Entity | yes | 1 session |
| 7 | **Modifications & clothing styles** | the 15 Item / clothing modifications and the 15 clothing styles get records; report and name-check coverage (§5.1) | none (goldens must match) | 1–2 sessions |

About 10–13 sessions. Phase 1 is the only one that touches central code; after it every Item is added the same way a
Trait is today. Phase 7 was added on 2026-10-23 at the user's request.

### 5.1 Phase 7: modifications and clothing styles

**Today.** Neither is an entry, so the registry, the report and the name-check counter don't see them:
- **Modifications** (`DB.itemMods`, 15: Material Means, Stunning Style, Size Matters, Gemstone Accessory, Enhanced Armory,
  Malice Infused, Profane, Miracle Infused, Sanctified, Tsukumogami, Reload, Sentimental Memento, Magick Foci, Power
  Armor Upgrade, Artifact of Power). Their effects are name checks on the modification (`m.n==="…"`): about 30, mostly in
  itemmods.js (`modEffects` modifiers, `modVirtuals` granted entries, weight, EPD, Mana stores), plus actions.js,
  ui_items.js, engine.js and a few records in reg/ (Power Armor Upgrade, Tsukumogami, Size Matters, Enhanced Armory).
  Two variants that aren't in the list (Replica, Item Flux) are handled in the same code.
- **Clothing styles** (`STYLES` in engine.js, 15: Practical, Skimpy, Comfy, Form Fitting, Classy, Plain, Cute, Well-Worn,
  Fortified, Super, Sexy, Ugly, Cool, Slutty, Conservative). Each has data (modifiers, CD multiplier, "no CD penalty")
  and some have rules written as name checks in actions.js (Classy, Plain), more.js (Cute, Fortified), itemmods.js
  (Fortified weight) and records (Fashion Coordinator in reg/soul.js names all of them; a few physical Traits name one).
- The 169 **clothing pieces** need nothing: they are layer / weight / CD data with flavour text, and the shared clothing
  system does everything they do.

**Design.**
- Two small record kinds next to the books: `MOD("Material Means", {…})` in a new `reg/mods.js` and
  `STYLE("Classy", {…})` in `reg/styles.js`, kept in their own maps (`MODS`, `STYLES_REG`) so their names can't clash
  with entries.
- **Modification slots:** `effects(o, m, add, addMods)` (its modifiers on the piece's owner, from `modEffects`),
  `grants(o, m)` (the entries it gives, from `modVirtuals`), `weight(o, m, w)`, `epd(o, m, ep)`, `ui(list, i, j, m)`
  (its options in the modification panel), plus the existing hook slots where a modification reacts in play (e.g. Size
  Matters, Power Armor Upgrade).
- **Style slots:** its data stays in `STYLES` (modifiers, CD multiplier, `nocd`). Rules become slots called by the
  clothing code: `cdRestore(piece, amount)` (Plain ×2, Classy SP × 10), `hit(piece, part, amount)` (Classy, Fortified,
  Cute), `spDamage` (Plain), `weight` (Fortified), `zeroCD` (Well-Worn), `spellCost` (Comfy).
- Records that care which style a piece has (Fashion Coordinator, Ugly-related Traits) keep naming the style: that's
  data about another rule, like a Trait naming a Status Effect.

**Coverage.**
- **Report:** two new sections, "Item modifications" and "Clothing styles", using the same rule as for entries (done when
  it has data or a record). Their entries are not added to the entry total.
- **Name-check counter:** a third count, "modification / style names outside reg/". It starts at about 30 and must reach 0
  in this phase, then never rise.
- **Tests:** existing goldens and interaction scripts must match unchanged (a pure move). New goldens per modification
  (one item with it, equipped, through the generic Item script) and per style (one clothing piece with it, hit, repaired,
  rested), recorded before the move, like phase 0.

---

## 6. Decisions (user, 2026-10-23)

- **Version numbers:** one patch number per phase (phase 0 = v0.4.11, phase 1 = v0.4.12, …).
- **Per-copy behaviour:** one record call per equipped copy.
- **Pacification Equipment initiation:** keep the panel, and offer "place [Item]" after a landed roll of the matching
  type when the attacker holds that Item.
- **Narrative Utility Items:** stay "rule text + note".
- **Seals:** only the combat-relevant Authorities are automated.

---

## 7. Phase 0 results (v0.4.11)

- **Goldens:** `build/test/harness.js` lists Items among `ENTRIES` and runs them through `genericItem`: equip, attack
  (Weapon User attacks with the weapon), be attacked, grapple, grope / be groped, violate / be violated, defend,
  Sensitivity Rolls, Pacification Equipment placed on the opponent through the panel's `peAdd` (and the opponent acting
  while it's on), the entry action, three turns, unequip and equip (`afterBind`, so the AP cost runs), drop and pick up,
  rests, battle end. 448 scenarios recorded from v0.4.11 with their reason; 2384 in all, all matching; no step errors.
- **Report:** Items are the eighth book: **972 / 1186** entries have behaviour (35 Items). The 189 open Items are filed in
  report-notes.json under new work groups, one per phase: Pacification Equipment 47, Expendables 8, Apparel 7, combat
  Utility 25, Seals 72, plus 30 narrative tools as Narrative / GM. The Pacification Equipment that counts as done through its
  data is listed as partial (its own effects are phase 2).
- **Name-check counter:** `audit.js` also counts lines outside reg/ that spell out an Item's name: **19** (baseline
  stored in audit-baseline.json as `items`; build.js stops if either count rises).
- **Full check:** goldens 2384 / 2384, interaction scripts all match except the known "casting" (Lock On fix), tables 32
  differences (unchanged), rules 40 / 40.

## 8. Phase 1 results (v0.4.12)

- **Owners** (reg/core.js): `REG_BOOKS` includes "Item". `regOwned` adds one row per equipped copy (`itemActive`: equipped,
  not dropped, not stored; no de-duplication by name; "by hand" skips the copy); `regSig` also tracks `stored`.
  `regRule` / `regBoost` read equipped Items after the other sources. Placed Pacification Equipment calls its record's
  `applied` slots for the wearer (a new call kind, `REG_APPLIED`), skipping disabled, broken and "by hand" pieces; the
  placer argument is null until phase 2 stores who placed it (storing it now would have changed every Pacification
  Equipment snapshot).
- **Item slots:** `item` (static properties), `proficiency`, `use`, `equip` / `unequip` / `dropped`, `itemUI`, `applied`.
  `use` shows a Use button on the Item's card (section 4) and in the Combat Dashboard's Items widget (not in the Abilities
  card: one place per Item is enough there); `useItem` spends the cost under "Abilities spend their cost", runs the record
  (or only logs it "by hand") and consumes one (quantity, then the Item). Events fire from `afterBind` (equip /
  unequip), `pickUp` and `dropHeld`.
- **Helpers** (reg/shared.js): `itemRec`, `itemIs`, `itemFor`, `itemsNamed`, `hasItem`, `itemCount`, `regActs`, `itemEvent`.
- **Records** (new reg/item.js): Weapon User (`item.weapon`, Scavenge's weapon), Shield Bearer (`item.shield`), Something
  of Note (`item.mode`, Scavenge's other finds), and the six Item Proficiency rows. The shared code asks these instead of
  the names: the weapon list and EPD (actions.js, ui.js), the Shield roll type, Something of Note's equip mode (engine.js
  itemProps, ui_items.js, itemmods.js sonSync and the modification categories), Scavenge (more.js). **Item-name counter: 19 → 0.**
- **Report:** a record with only `item` / `proficiency` doesn't count as behaviour, so Medical Mending (counted before only
  because its name sat in the Item Proficiency list) is open again, filed under phase 3: **971 / 1186**.
- **Checked:** a temporary record in the test frame confirmed per-copy calls (two copies, two bonuses; one "by hand" drops
  its own), an Item rule through `regRule`, the equip event, Use with cost and consumption, and an `applied` modifier on
  the wearer. Full check: goldens 2384 / 2384, interaction scripts all match except the known "casting", tables 32,
  rules 40 / 40. The sheet loads with no console warnings.

## 9. Phase 2 results (v0.4.13)

- **Placing:** placed pieces store their placer (`r.by`). After a landed roll, `peOffer` (advanced2.js, from `landedHooks`) offers to
  place each equipped Pacification Equipment the roll type can initiate ("Initiated By …"); `pePlaceOn` moves one copy
  from the holder to the target's row (Violate: the hole hit; Lewd ointments: the zone hit; else the default part) and
  fires `placed`. The panel's Apply also stores the placer and fires `placed`; `peRm` fires `removed` (refused while
  locked); `peEscape` uses `peStr` and fires `escapeFail`.
- **Worn vs held** (`peWorn`: Wearable / Insertable): worn pieces act on the wearer through `applied` slots, whether
  placed or worn by their owner (`wornList`); held tools act through their holder's own slots. A held piece's data
  modifiers no longer apply to its holder (bug: Sedative / Brainwash Oil gave the holder −10); a placed piece's data
  modifiers apply to the wearer × its applications.
- **Records** (reg/item.js, 43 pieces): Blindfold, Trance Goggles, Brainwashing Headphones; Bell, Victim and Shock Collar +
  Remote; Ball, Ring, Dildo, Strap-On, Funnel and Tentacle Gag (the Oral block is one `always.block` on Ball Gag reading
  every target's `worn` rules); all eight vibrators + Remote (rings every turn; others on the Remote or when used held;
  Wand / Rabbit keep the higher of two rolls); Chastity Device, Hardening Glue, Special Key, Steel Chains, Tape, Zip Tie;
  Paddle, Cane, three floggers, Leather Bullwhip; Aphrodisiac / Sedative / Brainwash Oil; Anal Beads, Crystal Butt Plug.
  Interpretations: "paired" with a remote or key = placed by its holder; held tools count as used while equipped (or
  while their "Using" toggle is on); Crystal Butt Plug's flipped MR = −2 × MR at turn start; Brainwashing Headphones resist
  against its own Roll Strength.
- **Still open** (report: 15 pieces, plus a partial table for 17): Bridle, the dildos, onaholes, Silicone / Tail Butt Plug,
  Rope, Bodysack, Net; Obedience Collar's commands; Tentacle Gag's own Violate; Payload injections; the Blindfold
  immunities.
- **Tests:** rules 49 / 49 (9 new); the 116 Pacification Equipment goldens re-recorded with the reason (no other scenario
  changed); the generic Item script skips unequip / drop when the Item is gone (Hardening Glue bursts); interaction scripts:
  "casting" and "incoming rules" (placer stored) differ as expected; tables 32. Report **1004 / 1186**. Checked in the sheet
  at 375 px (placed rows with Applications / switched off / Type, Items card with Use and the key's pairing).

## 10. Phase 3 results (v0.4.14)

- **Use** (ui_items.js): `use.cost` and `use.consume` may be functions of the copy; copies with several uses keep `o.left`
  (`usesOf` / `spendUse`). Targets: themself or a willing ally (`items.i.to`); force-feeding / injecting an Opponent is
  rule text.
- **Records** (reg/item.js): Consumable Connoisseur (type × weight from the tier: uses, AP 2 / 1, Lingering turns; effect,
  sign and roll / status picked on the item; the last Lingering one sets the duration of all; gags block), Pills &
  Injectables (the effect chart, read from the scrambled PDF table in order; Pill benefits start next turn via `next`,
  side effects follow from a queue at turn start; Overdosed and the defeat; rests reset), the medical supplies (weight
  0.1 via `item.w` in itemProps; Bandages / Gauze end Bleed, Compression Wrap negates Broken, Gauze falls off after three
  hits, Saline ends a Sustained Spell, Chlorhexidine clears penalties and blocks new ones for 3 turns with the Stillness
  flag, Quick Treatments clear their statuses), Explosive Crash (a special roll: `ownedSR` / `curSR` now include
  equipped Items; set off early by damage to its carrier), Special Ammo (`tierGate` without a ranged weapon; used up per
  ranged Attack).
- **Report:** one-line records (`REG("X",{ … });`) now count as their own records; before, they were folded into the next
  record's text, so Adhesive Surgical Tape counted as done. **1011 / 1186.** Medical Mending moved to Narrative / GM (its
  weight rule is applied by the supplies).
- **Tests:** the generic Item script presses Use ("use it" step), so all 448 Item scenarios were re-recorded with the reason
  (behaviour changed only for the Expendables and the Items that already had a Use); rules 54 / 54 (5 new); goldens
  2384 / 2384; interaction scripts: the two known differences; tables 34 (Explosive Crash added to SR).

## 11. Phase 4 results (v0.4.15)

- **Records** (reg/item.js): Mask and Pasties cover their zones while worn (`caps`, like Chastity Device); immunities
  through the normal `immuneTo` (equipped Items are registry owners): Scarf, Wristwatch (`immune` lists) and, by tier,
  Eyewear (Sunglasses), Earwear (Earplugs, Earmuffs), Hat (Tin Foil), Gloves and Socks (Wool), Footwear (Boots)
  (`immuneTest` via `tierImmune`); Fake Nails (`send`: +5 to the opponent's Sensitivity on a hand Lewd Roll); Cape (`dice`:
  Evasion disabled while a limb is Bound, read as "grabbed"); Pasties lost in battle (`unequip` / `dropped`): +10 Nipple,
  Pussy and Clit Sensitivity until removed. "Prevents Frigid / Chilled on [a body part]" is read as immunity to the
  status (statuses aren't per body part here).
- **Already data:** Tie, the tier modifiers and toggles of Eyewear, Hat, Gloves, Footwear, Socks, Enchanted Jewelry and
  Piercings (with the Item Mana pool).
- **Report:** **1014 / 1186.** Belt and Obedience Collar were counted as done only because another record's list names them
  (Chastity Device's types, the Special Key's eligible pieces); report-notes now marks them "main effect missing". Open:
  Cufflink, Belt; partial notes for 11 more.
- **Tests:** rules 59 / 59 (5 new); goldens: only Pasties and Fake Nails changed (re-recorded with the reason), 2384 / 2384;
  interaction scripts: the two known differences; tables 34.

## 12. Phase 5 results (v0.4.16)

- **Records** (reg/item.js): Banner (aura: +1 AP for allies under its holder's Sustained Spell), Spirit Stick (+20 RES for the
  holder and allies, −20 for 2 turns when dropped), Iron Bell, Spiritual Object (`castCost`), Laser Pointer, Professional
  Camera, Flashlight, EMP Ray, Cross (Use; carried: immune to Seal Authorities), Mirror / Unrefined Gemstone / Jet Boots
  (`reaction` with `has`, since `hasName` doesn't see Items), Gravity Drive / Magnetic Rise (`immuneTest` while Airborne),
  Augmented Reality Visor (Use switches mode; Aim Assist through `raw`; Thermal through `immuneTest`), Pressure Tank and Milk
  Rifle (the MJ tracker; the Rifle is a weapon whose `itemEPD` is the MJ spent). "Does not stack": one copy counts.
- **Open** (report): Pom Pom, Foam Finger, Jetpack, R.O.C.K.E.T, T.I.E.D.U.P, S.P.L.U.R as one set, D.R.A.I.N.

## 13. Phase 6 results (v0.4.17)

- **Summoning:** Otherworldly Entity's summon calls `sealSummon` (reg/item.js): the first equipped Seal becomes
  `entity.seal`; its record's `summon` can change the Entity (Orobas: turns ×2; Marchosias: damage ×2) and `summoned` acts
  once (Marbas, Sitri, Andras, Phenex). `demonOf(st)` is the summoner's active Demon; Authorities run through normal slots
  while it is present, `aura` for other characters and `always` for everyone. A target holding the same Seal or a Cross,
  or a summoner with Balam, isn't affected (`immuneTo`).
- **22 Authorities:** Bael (`always.block`: can't be targeted), Vassago, Marbas, Barbatos, Paimon / Buer, Sitri, Beleth
  (only Lewd / Violate, the summoner too), Leraje, Purson, Astaroth (`aura.apCost`), Furfur (Evasion halved; not the bolt),
  Focalor, Vepar, Balam, Gremory, Andras, Phenex, Cimeies, Andromalius, Orobas, Marchosias. The other 50 stay rule text
  (narrative, or too situational: Aim, Valefor, Sabnock, Shan, Raum, Decarabia, Dantalion …).

## 14. Phase 7 results (v0.4.18)

- **Records:** `MOD(name, {…})` in reg/mods.js for the 15 modifications plus Replica and Item Flux (slots: eligible,
  defaults, removed, effects, grants / grantKeys / soulKey, weight, od, epd, ui, style, legacy); `STYLE(name, {…})` in
  reg/styles.js for the 16 styles (the old STYLES table's data, plus noSP (Classy), spX (Plain), w (Fortified)). STYLES in
  engine.js is filled from the records; the Fashionista Spell's restyle options moved to its record (`itemOpts`). The
  legacy string-modification actions `itemMod` / `itemMat` (no button used them) were removed.
- **Shared code:** itemmods.js (eligibility, migration, style lookup, granted entries, effects, weight, OD), actions.js (EPD,
  adding / removing, the clothing hit's SP rules), engine.js (granted keys), ui.js / ui_items.js (chips, the options
  panel) ask the records. About 50 lines named a modification or style before; the new third counter is **0**.
- **Proof it's a pure move:** 33 new scenarios (each modification on a weapon / clothing / armor piece, each style on a worn
  piece: fights, clothing hits with and without SP, Sensitivity, turns, rests) were recorded **before** the move and all
  match after it.
- **Report:** modifications and styles listed beside the entries: 15 / 15 modifications with a record; 11 / 16 styles with
  modifiers or rules (description only: Comfy, Form Fitting, Well-Worn, Cool, Passé).

## 15. Checks for phases 5–7 (run once at v0.4.18, as asked)

- Goldens **2417 / 2417** after re-recording the 12 combat Utility scenarios whose Use now acts (Laser Pointer,
  Professional Camera, Flashlight, Iron Bell, EMP Ray, Visor), reason stored; every other scenario, including the 33
  modification / style ones, matched unchanged.
- Rules **67 / 67** (8 new: Spirit Stick, Mirror, Spiritual Object, Buer, Focalor, Bael, Beleth, Orobas).
- Interaction scripts: the two known differences ("casting", "incoming rules"); tables 38 (Explosive Crash in SR; Mirror,
  Unrefined Gemstone, Jet Boots in RX). The sheet loads without console warnings; the new Item controls fit at 375 px.
- Report **1055 / 1186**.

## 16. Follow-ups after the plan (still v0.4.18; checked in full on request)

- **Open Items done** (11): Pom Pom (`rules.sustainTwice` read by effects.js fxCastBlock with a Pom Pom on every Arm and
  Tentacle), Jetpack and Magnetic Rise (`moveCost` while Airborne), Lube (applications), Cufflink (`effMax` doubles a cuffed
  piece's Lower Arm CD), T.I.E.D.U.P (a special roll whose `raw` is 70, Bound Roll Strength 70), D.R.A.I.N (the ray as a
  Use; Milk sprays after Attacks and Spells through `always.afterRoll`), Cursed Dildo (a Favored Curse at d100, kept after a
  climax), Silicone Butt Plug, Rope, Bodysack, Titanium Carbon Fiber Net (`peBindParts` / `peFreeParts`).
- **New hooks / slots:** `moveCost` (positions.js), `equipBlock` (actions.js afterBind undoes the equip with a note:
  Footwear, Jet Boots, Fake Nails, Suction Cups, Jetpack), `wornImmune` (immuneTo also reads worn pieces: Blindfold).
  Items dropped by cleavage spilling or Think Fast now fire their `dropped` event.
- **Partial table:** 84 → 71 rows. Finished or stale (already done before): Godly / Adaptive Immunity, Pestilence, Charm,
  Mana Loan, the old "Use buttons" row, Talisman User (refill on rest), Blindfold, Lube, Anal Beads (moving), Eyewear,
  Footwear, Spirit Stick, Laser Pointer, Professional Camera, Magnetic Rise, Jet Boots, Animal Gear, and the rows that had
  nothing missing. Narrowed: Egg Laying Tentacle (growth and laying), Phantom Pain (Resistance retry), Ritual Channeling
  (the stored attack as a roll), Cape, Mirror, Cross, Suction Cups, Tentacle Gag, Payload Vibrator, Adhesive Surgical Tape.
- **Boosts:** Clairvoyance and Lesser Key (Holy reroll prompts), Cold Storage (Maternal Symbol; Milk is otherwise lost while
  casting is disabled). Still open: Combo Spell, Forbearance, Refined Gold (their base entries are narrative), Nosey Snout
  (the sheet can't tell who is hiding), Moovement (its 200 MJ requirement isn't tracked).
- **Not done** (need mechanics the sheet doesn't have): R.O.C.K.E.T, S.P.L.U.R as a set, Foam Finger (no AP upkeep for
  Sustained Spells), Belt (taking clothing), Obedience Collar's commands, Bridle, the other dildos and onaholes, Tail Butt
  Plug (Lewd at the Tail zone already gives a Tail Sensitivity Roll).
- **Checks:** goldens 2417 / 2417 (26 scenarios re-recorded with the reason: the new behaviour, and the Apply log now
  including what a placed piece did), rules 72 / 72 (5 new), interaction scripts the two known differences, tables 41
  (Ritual Channeling and T.I.E.D.U.P in SR, Think Fast's drop event). Report **1066 / 1186**. New controls checked at 375 px.

