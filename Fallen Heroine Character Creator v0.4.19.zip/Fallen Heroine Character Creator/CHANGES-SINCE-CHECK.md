# Changes since the last full check

Small changes and bugfixes made without a full check (goldens, interaction scripts, table fingerprints, rules check). Run the full check when building a new version number or on request, re-record expected differences with a reason, move these notes into HANDOFF.md, and clear this list.

**Last full check:** 2026-10-23, v0.4.19 — goldens 2417 / 2417; interaction scripts all match except "casting" (Lock On fix), "incoming rules" (placer stored) and "damage chain" (Sacratus landed text), all expected; tables 57 differences (41 known + 16 from the v0.4.19 Wall / Brace Yourself / imbue changes); rules 72 / 72.

## Since then

(nothing yet)
