# Framework audit (v0.4.2)

How each Characteristic, Trait, Blessing and Curse is implemented. **Unified** = handled entirely by the entry data (engine modifiers, tiers, toggles, counters, flags) and/or one registry table (ABIL, SR, SPELL_FX, FX_DEFS, RX, IMBUE, CURSE, BC_MANUAL, ADV, AP_ONLY, TRAIT_BOOSTS). **Not unified** = some or all of its rule lives in name checks (`hasName(st,"…")`, `boosted`, `bOn` / `cOn`) scattered through the hook code.

| Mechanism | Entries |
|---|---|
| Data only | 199 |
| Table only | 222 |
| Table + scattered checks | 158 |
| Data + scattered checks | 130 |
| Scattered checks only | 234 |
| No effect / rule text | 19 |
| **Total** | 962 |

| Book | Data only | Table only | Table + scattered checks | Data + scattered checks | Scattered checks only | No effect / rule text |
|---|---|---|---|---|---|---|
| Body Characteristic | 166 | 45 | 17 | 82 | 42 | 13 |
| Soul Characteristic | 11 | 12 | 9 | 19 | 10 | 5 |
| Physical Trait | 20 | 44 | 14 | 6 | 70 | 0 |
| Magic Trait | 2 | 101 | 65 | 4 | 60 | 1 |
| Blessing / Curse Trait | 0 | 0 | 37 | 11 | 32 | 0 |
| Blessing | 0 | 4 | 1 | 7 | 20 | 0 |
| Curse | 0 | 16 | 15 | 1 | 0 | 0 |

## Scattered checks only (234)

No data and no registry entry: the whole rule is name checks inside hooks.

**Body Characteristic** (42)

- Healthy — missed
- Attractive Privilege — encounter, extras
- Standard — hooks
- Lost In The Crowd — hooks
- Ankle Biter — encounter
- Intimidation — hooks
- Passed — advanced2
- Don’t Think, Feel — reactions
- Seductive Whisper — extras
- Balanced — missed
- Codependency — extras
- Gentle Lover — ui, encounter
- Rough Master — actions
- Bald — engine
- Stubborn Teats — more
- On Your Knees For Your Queen — hooks
- Possessive Hold — hooks
- Super Soaker — hooks
- Extra Quiet — actions
- Swift Form — ui, reactions, abilities
- Thicker Than Oatmeal — actions
- Mother Of A Thousand Young — engine
- Dual Set — locks
- G-Spot Expert — encounter
- On Your Knees for Your King — hooks
- Masochist — encounter
- Sadist — encounter, trackers, actions
- Quick Shot — extras, actions
- Aphrodisiac Cum — trackers
- Brainwashing Cum — trackers
- Invigorating Cum — extras, actions
- Firehose — ui, actions
- Hold It In — ui, actions
- Nosey Snout — advanced, boosts
- Padded Paws — advanced
- Extreme Stretchiness — engine, extras, more
- Avatar — encounter, more, large
- Scrubber Tentacle — boosts, encounter
- Milker Tentacle — boosts, encounter
- Bloom Tentacle — boosts, encounter
- Knotty Tentacle — boosts, hooks
- Egg Laying Tentacle — trackers

**Soul Characteristic** (10)

- Utility Mage — ui, abilities
- Magic Null — advanced
- Miasma Immunity — ui, encounter
- Perfect Miasma Control — bc, more
- Henshin A Go Go Baby! — engine, forms
- Energy Blast — advanced2, actions
- Talisman User — trackers
- Sharpshooter — encounter
- Habitual Defense — engine
- Early Sacrifice Exchange — engine, ui

**Physical Trait** (70)

- Armor Piercing Blow — actions
- Blue Blood — more
- Confused — more
- Cracked — more
- Cleave — more, large
- Bulldozed — abilities
- Patience Is A Virtue — trackers
- Whirlwind Dance — encounter
- Weapon Mastery — trackers
- Vacuum Blast — encounter
- Feint — ui, abilities, actions
- Counter Dodge — reactions, abilities, actions
- Parry — reactions, abilities
- Charge! — ui, actions
- Drag! — more, missed
- Assassin — ui, actions
- Leave No Witnesses — effects
- Hidden Stash — specials, actions
- Concealed Surprise — actions
- Protector — specials, more
- Coward — specials
- Determined — holds, bc
- Deflect — reactions
- Escape Artist — actions
- Shake It Off — ui, abilities
- Observant — trackers, more
- Shield Mastery — more
- Swagger — encounter
- Centerpiece — abilities
- Too Cool For You — extras
- Outshine — abilities
- Flourish — abilities
- Showboasting — abilities
- My Turn Loser — extras
- Stylish Finisher — trackers, actions
- Quick Change — actions
- Cast By Style — abilities
- Death Grip — layout, actions
- Tight Hold — actions
- Squeezing Hug — encounter
- Tension Relief — trackers
- Excitement — trackers
- Fist Deep — encounter
- Dress Malfunction — clothaccess
- Nipple Play — encounter
- Clit Play — encounter
- Beastly Desire — trackers
- Molester — trackers
- Wrongful Insertion — ui
- Pheromone Attraction — positions
- Quick Draw — actions
- Quick Retrieval — actions
- Blinding Draw — actions
- Swift Withdraw — actions
- Right Back At Ya — specials
- Mouthful — ui_items
- Right To Bear Legs — ui_items
- Massage Therapist — actions
- Professional Dom — actions
- Polymorphic — more
- Multipartite — more
- Companion — more
- Power Rest — actions
- Gourmet Chef — trackers, hooks
- Demolition Delight — trackers, hooks
- Mobile Pharmacy — engine, trackers
- Trick Shot — ui, encounter, trackers
- Proper Cleaning — abilities
- Alert — actions
- Cool Down — actions

**Magic Trait** (60)

- Tri Elemental Mastery — specials
- Arc-en-Ciel — specials
- Yin Yang Mastery — more
- True Elemental Mastery — specials
- World Flow — specials
- Elemental Break — encounter
- Overcharged — boosts, actions
- Lock On — boosts, reactions, more
- Double Cast — boosts, trackers
- Boom Expert — boosts, abilities
- Omni-Directional — boosts, abilities
- Charge Party — boosts, more, actions
- Careful Casting — boosts, more
- Selective Casting — boosts, abilities, more
- Rapid Fire — ui, boosts, actions
- Power Bomb — boosts, more
- Dense Mix — boosts, actions
- Combo Spell — boosts
- Mana Drip — boosts, trackers
- Fatigue — boosts, hooks, actions
- Mana Loan — boosts, trackers, more
- Separate — more, missed
- Reinforced Protection — more
- Polarity Crash — trackers
- Polarity Cushion — trackers
- Static Charge — encounter
- Static Burst — encounter
- Technokinesis — more
- Reroute — more
- Portal Slice — more
- Levitation — advanced2, actions
- Flight — advanced2, actions
- Slow — ui, effects, actions
- Independence — more
- Highlight — effects
- Lewd Healing — encounter
- Cast From Lewd — abilities
- Erotic Casting — abilities
- Disorientation — more
- Defense Shatter — specials
- Shockwave — more
- Amplify — encounter, specials
- Projection — more
- Skilled Support — ui, effects
- Cast From Body — abilities
- Life Drain — trackers
- Heal — actions
- Aggressive Care — encounter
- Overflowing Vitality — effects
- Divine Healer — boosts, effects
- Inner Flow — more
- Shining Spirit — actions
- Soul Absorption — trackers
- Heavenly Depths — actions
- Level Drain — encounter
- Item Reconstruction — more
- Cast By Material — abilities
- Resize Convenience — more
- Refresh — boosts, trackers, extras
- Cold Storage — boosts, trackers, actions

**Blessing / Curse Trait** (32)

- Truly Heavenly — boosts, extras
- Generous Split — ui, boosts, actions
- Blissful Soul — boosts, bc
- Radiance — boosts, bc
- Forbearance — boosts
- Brilliant Light — boosts, hooks
- Godly — boosts, encounter, extras
- Panacea — boosts, bc
- Entwined Lives — boosts, bc, more
- Quick Prayer — boosts, bc
- Unsullied Body — boosts, bc
- The Power of Friendship — boosts, hooks
- All-Mother — boosts, more
- Adaptive Immunity — boosts, encounter, extras
- Social Faux Pas — clothaccess, boosts
- Saintly Aura — boosts, bc
- Ritual Channeling — boosts, trackers
- One-Man Army — boosts, hooks, actions
- Composure — boosts, bc, actions
- Justice Enforcer — boosts, extras
- Twice Blight — boosts, bc
- Clingy Miasma — boosts, encounter
- Infection — boosts, bc
- Mutual Feelings — boosts, bc
- Egg Nuke — boosts, bc
- Cocky Bitch — boosts, bc, more
- Overflowing Confidence — boosts, bc
- Positive Reinforcement — boosts, hooks, missed
- Spaced Out — boosts, bc, more
- White Vampire — boosts, bc, more
- Fatal Obsession — boosts, bc, more
- Info Seducer — boosts, bc

**Blessing** (20)

- Ataraxia — bc
- Camaraderie — bc, more
- Continence — bc
- Deliberation — more, actions
- Gleam — bc
- Lajja — encounter, bc, more
- Lofty — bc
- Loom — bc, more
- Memorandum — bc
- Memorize — bc
- Poise — bc, actions
- Reverence — bc
- Solomon — bc, more
- Soteriology — bc
- Steadfast — bc
- Stringent — bc
- Tithe — bc
- Vestal — bc, more
- Violence — bc
- Womanhood — bc, actions

## Data + scattered checks (130)

The numbers come from the data; the rest of the rule is name checks inside hooks.

**Body Characteristic** (82)

- Athletic — missed
- Swole — missed
- Greek Statue — missed
- Please Be Gentle — missed
- Ethereal Beauty — missed
- Professional Wrestler — missed
- Stout Strength — engine
- Mini — hooks
- Shorty — hooks
- Petite — hooks
- Lanky — hooks
- Statuesque — hooks
- Giant — hooks, more
- Contortionist — missed
- Super Mini — more
- Super Giant — hooks, more
- Clean Conscience — missed
- Perverted Thoughts — missed
- Switch — forms
- Tangled — engine
- Starry — missed
- Jaded — missed
- Blind Savant — more, missed
- Oral Innocence — bc, more, large
- Popped Throat Barrier — bc, more
- Slurp — missed
- Massive Mana Jugs — more
- Gargantuan Mana Jugs — more
- Concentrated Mana Milk — missed
- White Fountain — missed
- Awakened Power: Nipples — missed
- Supercharged: Nipples — missed
- Fuckable Nipples — ui
- Extra Tight Pussy — missed
- Vice Grip — missed
- Untouched Flower — bc, more, large
- Deflowered — bc, more
- Sensational Dancer — missed
- Slick Walls — missed
- Awakened Power: Clit — missed
- Supercharged: Clit — missed
- Unstretched — bc, more, large
- Forbidden Pleasure — bc, more
- Mana Void — missed
- Packing Heat — more
- Stallion — more
- Behemoth — more
- Girthy — missed
- Herbivore — bc, more, large
- Stud — bc, more
- Double Cocked — large
- Extra Thick Load — actions
- Purifying Cum — missed, actions
- Corrupting Cum — missed, actions
- Wondrous Wings — advanced, boosts, more
- Multi-Tailed — engine, advanced, large
- Animal Ears — advanced, boosts, trackers, more
- Twitchy Antennae — advanced
- Dangerous Claws — advanced, boosts, large, actions
- Fuzzy Fluff — boosts
- Shiny Scales — boosts
- Plushy Plumage — boosts
- Slippery Slime — boosts
- Serpentine Creature — advanced, boosts
- Exotic Meat — advanced
- Multi-Armed — engine, advanced
- Multi-Legged — engine, advanced, more
- Multi-Headed — engine, advanced
- Headless — missed
- Off With Their Head — engine
- Multi-Breasted — advanced
- Lead Weight — holds, missed
- Rooted — engine
- Amorphous Blob — holds, more, large
- Undead — holds, more, missed, large
- Metallic Frame — holds, more
- Multi-Tentacled — engine, advanced
- Tentacle Abomination — boosts
- Roper Tentacle — boosts, more
- Bumpy Tentacle — boosts, encounter
- Girthy Tentacle — boosts, holds
- Slippery Tentacle — boosts

**Soul Characteristic** (19)

- Chastity Barrier — itemmods, ui, advanced, actions
- Elemental Affinity — specials, more
- Magical Girl Transformation — engine, forms
- Super Mode Transformation — engine, holds, actions
- Carnal Mode Transformation — engine
- Immortal — engine, ui, more, large
- Apparition — specials, more
- Tarnished Heart — engine, bc
- Inner Confidence — missed
- Special — engine, ui, actions
- Chosen Discipline — missed
- Toxicology — large
- Shinobi No Jutsu — large
- Popularity Contest — missed
- Transformative Mech Suit — more
- Righteous — missed
- Tainted — missed
- Hard Worker — engine, ui
- Master of One — actions

**Physical Trait** (6)

- Reversal — missed
- Prepared — missed
- Relentless — missed
- Hardened Body — holds, missed
- Regeneration — holds, missed
- Fashion Coordinator — missed

**Magic Trait** (4)

- Elemental Resistance — more
- Elemental Immunity — more
- Elemental Absorption — advanced, more
- Elemental Boost — missed

**Blessing / Curse Trait** (11)

- Weaved Fate — boosts, more
- A Little Beastly — boosts, more
- Desperate Strength — boosts, more
- Rebellious Brat — boosts, more
- Freedom — boosts, more
- Mana Overflow — boosts, more
- Reverse Flow — boosts, more
- Obedience Reward — boosts, bc
- Hardcore Masochism — boosts, bc
- Power Word — boosts, more
- Feel The Love — boosts, bc

**Blessing** (7)

- Ascension — engine, bc, actions
- Figuration — bc, more
- Galvanize — hooks, bc
- Imperious — engine, actions
- Seal — engine
- Self-Sufficiency — hooks, bc, actions
- Tribute — bc

**Curse** (1)

- Sensitivity — engine, advanced, compact, actions

## Table + scattered checks (158)

Registered in a table, but other parts of the rule are name checks elsewhere.

**Body Characteristic** (17)

- Sticks & Stones — SR; encounter, specials, extras
- Come Get Some — ABIL; hooks, extras
- High-Pitched Shriek — SR; specials, more, missed
- Incantation — ABIL; abilities, extras
- Ventriloquist — ABIL; extras, actions
- Indomitable — RX; holds, more
- Through The Veil — ABIL; more, missed
- Sneak Peek Distraction — SR; specials, missed
- Squeeze — ABIL; advanced, missed
- White Projectile — SR; advanced, missed
- Prehensile Tail — AP_ONLY; engine, advanced, boosts, more, large
- Horny — AP_ONLY; engine, advanced, boosts, actions
- Beast Tongue — AP_ONLY; engine, advanced, boosts, large, actions
- Sharp Fangs — AP_ONLY; engine, ui, advanced, boosts, large, actions
- Modification Tentacle — SR; boosts, specials, more
- Stalker Tentacle — SR; boosts, specials, missed, actions
- Spindly Tentacle — ABIL; boosts, more

**Soul Characteristic** (9)

- Mana Barrier — ADV; engine, advanced, holds, more, missed
- Magic Resistant — RX; specials, more
- Draconic Spirit — TRAIT_BOOSTS; boosts, holds
- Holy — TRAIT_BOOSTS; boosts, more, missed
- Demonic — TRAIT_BOOSTS; boosts, bc, more, missed
- Silver Heart — TRAIT_BOOSTS; engine, boosts, bc
- Polemokinesis — ADV; engine, advanced
- Dedicated Warrior — ADV; engine, ui, advanced, advanced2, actions
- Battle Dancer — AP_ONLY; engine, advanced, more, missed

**Physical Trait** (14)

- Quick Strike — SR; reactions, extras
- Carry! — ABIL; more, missed
- Devious Trap — ABIL; trackers, hooks
- Stealth — ABIL; effects, abilities, bc, missed
- Sticky Fingers — SR; specials, large
- Afterimage — ABIL; abilities, bc
- Brace Yourself — RX; holds, more
- Block — RX; holds, more
- Striking Pose — ABIL; abilities, extras
- Lift — ABIL; extras, missed
- Brown Bagger — ABIL; trackers, hooks
- Explosive Cook — ABIL; trackers, hooks
- Prepared Aid — ABIL; trackers, hooks
- Ammo Run — ABIL; trackers, hooks

**Magic Trait** (65)

- Fulgur: Pure — IMBUE; encounter, specials
- Glacialis: Pure — IMBUE; encounter, specials
- Sacratus — IMBUE; ui_items, boosts, specials, more
- Incendium: Corrupted — IMBUE; encounter, specials
- Malignus — IMBUE; ui_items, boosts, specials, more, actions
- Rune Trap — SR; boosts, trackers, hooks, actions
- Magic Mimicry — ABIL; boosts, more
- Copycat — ABIL; boosts, trackers, hooks
- Sharing Is Caring — ABIL; boosts, abilities
- Mana Aura — ABIL; boosts, abilities, actions
- Mana Cocoon — ABIL; boosts, holds, more, actions
- Magic Devour — RX; boosts, holds, more
- Anti-Magic — FX_DEFS; boosts, effects, actions
- Incorporeal — FX_DEFS; boosts, effects
- Shift Phase — ABIL; boosts, holds, more
- Armory Creation — SPELL_FX; boosts, hooks
- Phantom Armor — SPELL_FX; boosts, hooks
- Unseen Hand — SR; specials, extras
- Hold — FX_DEFS; advanced, missed
- Push & Pull — SPELL_FX; more, missed
- Fling — SPELL_FX; more, missed
- Wall — ABIL, RX; holds, more
- Polarity Charge — SPELL_FX; ui, trackers, hooks, more
- Reverse — RX; holds, more
- Stop — ABIL; holds, more
- Exchange — SPELL_FX; more, missed
- Portal Creation — RX; holds, more
- Inter-Dimensional Storage — SPELL_FX; ui, hooks
- Gravity Well — FX_DEFS; effects, more, missed
- Item Flux — SPELL_FX; itemmods, more
- Shadow Puppetry — SPELL_FX; hooks, more
- Void — FX_DEFS; effects, missed
- False Doll — SPELL_FX; hooks, bc
- Phantom Pain — SR; extras, more
- Invisibility — FX_DEFS; effects, bc, missed
- Unseen Danger — FX_DEFS; effects, missed
- Hypnotic Suggestion — SR; boosts, specials, extras, more, missed
- Honeyed Words — SR; boosts, specials, extras, missed
- Hypnagogic Tone — ABIL; boosts, abilities, extras, more, missed
- Help Me — SR; boosts, specials, extras, more, missed
- Hibernate — FX_DEFS; boosts, effects
- Heart Knight — FX_DEFS; boosts, effects
- Heartthrob — ABIL; boosts, hooks
- Heroine Fallen — SR; boosts, specials, more
- Detox — SPELL_FX; abilities, bc
- Clot — FX_DEFS; effects, actions
- Empower — FX_DEFS; ui, effects
- Depower — FX_DEFS; ui, effects
- Revive — SPELL_FX; abilities, bc
- Cleanse — SPELL_FX; boosts, abilities, bc
- Purify — SPELL_FX; boosts, abilities, bc
- Stillness — FX_DEFS; boosts, effects, actions
- Purge — SPELL_FX; boosts, abilities, bc
- Exonerate — SPELL_FX; boosts, bc
- Contraceptive Magic — FX_DEFS; boosts, effects
- Innocence — SPELL_FX; boosts, abilities
- Anima — ABIL; more, actions
- Soul Rend — SR; specials, large
- Dribble — FX_DEFS; boosts, effects, more
- Suckle — SPELL_FX; boosts, trackers, hooks
- Creampuff — SR; boosts, trackers, extras
- Pasteurization — ABIL; boosts, trackers, extras, actions
- Moovement — FX_DEFS; boosts, effects
- Nurse — ABIL; boosts, trackers, extras
- White Armoury — ABIL; boosts, trackers, hooks

**Blessing / Curse Trait** (37)

- Miraculous Gift — ABIL; boosts, more
- Sanctified Article — ABIL; boosts, more
- Soul Searching — ABIL; boosts, abilities
- Refined Gold — ABIL; boosts, more
- Adrenaline Rush — ABIL; boosts, more
- Preserved Form — ABIL; boosts, bc, more
- Glitter Glue — ABIL; boosts, bc, more
- Impeccable Timing — ABIL; boosts, more, actions
- Handholding — ABIL; boosts, bc
- Clairvoyance — RX; boosts, bc
- Mother of Learning — ABIL; boosts, extras
- Chi Block — SR; boosts, specials
- Lesser Key — ABIL; boosts, more
- Empyreal Plane — ABIL; boosts, bc
- Blaze of Glory — ABIL; boosts, bc
- Sacred Ground — ABIL; boosts, bc
- Life Advice — ABIL; boosts, bc
- Virgin Hope — ABIL; boosts, bc, more
- Yoni Worship — ABIL; boosts, bc
- Curse Sight — ABIL; boosts, effects, bc
- Malicious Gift — ABIL; boosts, more
- Delayed Disaster — ABIL; boosts, bc
- Pestilence — ABIL; boosts, hooks, bc
- Profane Article — ABIL; boosts, more
- Autosuggestion — ABIL; boosts, reactions, hooks, extras, missed
- Glutton — ABIL; boosts, hooks
- Mating Bond — ABIL; boosts, bc
- Flasher — ABIL; boosts, bc, missed
- Pitiable — ABIL; boosts, bc, more
- Milk Drink — ABIL; boosts, bc
- Spank Material — ABIL; boosts, hooks
- Charm — ABIL; boosts, hooks, more
- Alt-Ego — ABIL; engine, boosts, abilities, more, actions
- Premonition Of Perversion — RX; boosts, specials, more
- Compensation — ABIL; boosts, extras
- Slutty Upgrade — ABIL; engine, boosts, more
- Blue Balled — ABIL; boosts, hooks

**Blessing** (1)

- Faith — RX; bc, more

**Curse** (15)

- Animalistic — CURSE; bc, more
- Chained — CURSE, BC_MANUAL; bc, more
- Command — CURSE, BC_MANUAL; extras, bc, missed
- Futafication — CURSE, BC_MANUAL; bc, more
- Inferiority — CURSE, BC_MANUAL; effects, bc
- Lesser — CURSE, BC_MANUAL; bc, more
- Liberated — CURSE, BC_MANUAL; bc, actions
- Libido — CURSE, BC_MANUAL; hooks, bc
- Pheromone — CURSE, BC_MANUAL; bc, more
- Receptacle — CURSE, BC_MANUAL; bc, more
- Siphoning — CURSE, BC_MANUAL; bc, more
- Sway — CURSE; bc, more
- Task — CURSE, BC_MANUAL; extras, bc, missed
- Triggered — CURSE; abilities, extras, bc, missed
- Vibrancy — CURSE, BC_MANUAL; engine, bc, more

## Notes

- Blessings have no registry table of their own (Curses have CURSE); most Blessing rules are `bOn(st,"…")` checks in bc.js.
- The Curse "Sensitivity" is not in the CURSE table.
- The Traits that boost others (Prodigious Spellslinger, Holy, Demonic, Silver Heart, Draconic Spirit, Maternal Symbol) are a table, but each boost is applied by a `boosted(st,"…")` check where the boosted entry is handled.
