# Ruleset check plan

**Goal:** go through every implemented entry and compare what the sheet does with its rule text. Fix the gaps, and record each verdict. The v0.4.19 passes (Polarity Charge, Wall, Elemental imbues) found wrong numbers, missing clauses and effects that existed only as text. This plan does the same for everything else, in order of how easy each entry is to check.

Written 2026-10-23 at v0.4.19, for a new session.

---

## 1. Tools

- `node build/test/check-groups.js` writes `build/test/check-groups.json`. It holds every entry's tier, effort score, data fields, record slots, file, the entries its text names, and its partial-table note. It also prints the tier counts and progress, read from `check-log.json`. Rerun it after a batch.
- `node build/test/check-entry.js "Name" ["Name" …]` prints one entry on one screen:
  - its tier;
  - its rule text and data fields;
  - its registry record;
  - other records and shared-code files that name it;
  - its partial-table note.
  
  Start every check here.
- `build/test/check-log.json` holds the verdicts: one row per checked entry, `{v, verdict, note}`.
  - **ok:** matches the rules.
  - **fixed:** was wrong, now matches.
  - **gap:** left as rule text; say what is missing.
  - **ruling:** waiting for the user.
  
  It is seeded with the 24 entries checked in v0.4.19 and v0.4.9.
- Full rule text is in `build/raw/*.clean.txt`. Use it when an entry's `x` text is cut short or a mechanic is defined elsewhere, such as Status Effects in BaseMechanics.

## 2. Tiers (how easy an entry is to check)

| Tier | What it is | How to check | Entries |
|---|---|---|---|
| **T1** data only | Effects only in the data (modifiers, tiers, toggles, flags, conditions); no record | Compare the numbers and conditions with the text. A long text (400+ characters) often has clauses the data can't express | 263 (213 short, 50 long) |
| **T2** simple record | A record whose slots are all declarative (`rules`, `immune`, `mods`, `caps`, `dice` …), or behaviour that lives in another entry's record or the shared code | Read the record and every place that reads its rule | 181 |
| **T3** hooks | Event hooks (`landed`, `damaged`, `turnStart`, `send`, `aura` …) | One scenario per hook in the sheet; add an interaction script when state changes | 136 |
| **T4** interactive | Buttons, special rolls, Spells, reactions, imbues, Curses, advanced editors, prompts | Play it through in the sheet, including costs, limits, cooldowns and the opponent's side | 263 |
| **T5** family | T3 / T4 entries whose text names three or more other entries (Specialties, combinations, requirements) | Check the whole family together, as was done for Magnokinesis, Wall and the Elementals | 223 |
| out of scope | Open (17), narrative / GM (91), no effect (12): the report's list | Not a check: these need implementing (see `unimplemented-entries.html`) | 120 |

Effort scores (rule text length + slots + record size + partial note) per tier: T1 356, T2 583, T3 524, T4 1129, T5 1848. T5 is about five times T1 per entry.

## 3. Phases

Each phase ends with the full check and, if the user wants, a version bump (see section 5). Inside a phase, work in batches of about 15–30 entries, or one family / school.

### Phase 1: T1 short, data only (213; Body 176)
- **Semi-automatic.** Write `build/test/check-numbers.js`. It pulls "+N / −N Roll", "×N", "÷N", "Doubled / Halved" and "Lasts N Turns" from the rule text and compares them with `m` / `t` / `c` / `fl` in the data.
- Read by hand only the flagged entries and those with words the data can't hold: "Once per", "instead", "can't", "Immune", "when", "if".
- **Batches:** Body by group (Height, Weight, Hair, Eyes, Lips, Breast, Pussy, Cock …), then Physical / Soul / Item / BCTrait / Magic / Blessing (24 in all).
- **Expect:** wrong signs or numbers, missing conditions, and clauses that need a record. Moving a clause into a record moves the entry to T2 or T3.

### Phase 2: T1 long + T2 (231)
- **Long T1 (50):** the data covers the modifiers, but the text usually has more. Examples: Hyper Sensitive Body, Handicapped, Silk Hiding Steel, Extreme Endurance, Super Giant, Contrarian, Oral Innocence, Empty Cup.
- **T2 (181):** read every place that checks the rule or immunity (`regRule(…,"x")`, `immuneTo`). The 51 T2 entries without their own record, such as Healthy, Standard, Bald, Don't Think Feel and Padded Paws, live in shared code or another record. `check-entry.js` lists where.
- **Batches by book:** Body 61, Physical 48, Item 40, Magic 39, Soul 29, BCTrait 12, Blessing 2.

### Phase 3: T3 hooks (136)
- **Per entry:** set up the triggering event in the sheet (two tabs, Near, start battle) and check the outcome against the text. Do this for every hook the record has (`check-entry.js` shows them).
- **Batches by book:** Item 26, Body 25, Physical 24, BCTrait 23, Magic 19, Blessing 15, Soul 4.
- **Watch for:**
  - who the hook fires for (owner, opponent or ally);
  - turn timing (start or end, whose turn);
  - "once per turn / battle" limits;
  - stacking.

### Phase 4: T4 interactive (263)
- **Sub-phases:**
  - 4a Magic Traits by school (107): Tychokinesis, Enthrallment, Hemokinesis, Hallucikinesis, Erokinesis, Animakinesis, Transmutation, Telepathy, Lactokinesis, Manakinesis, Gyrokinesis …
  - 4b Physical (45).
  - 4c Items (42, mostly Pacification Equipment and Utility).
  - 4d Blessing / Curse Traits, Curses, Blessings (35).
  - 4e Body / Soul (34, Tentacle and Lips first).
- **Per entry, check:**
  - the cost: AP / Mana / SP, and AOE vs single;
  - the roll used and the defence chain;
  - range limits;
  - what it does on land and on a miss;
  - its duration and cooldown;
  - the opponent's view (incoming card, reactions).

### Phase 5: T5 families (223)
- **Families by size:** Lewd Curse (25), Non-Human (12), Chaste Blessing (12), Koinos Kosmos (10), Item Utility (9), Manakinesis (8), Blessing Traits (8), Personality (7), Idios Kosmos (6), Sanitization (6), Curse Traits (6), Voice / Pussy / Gyrokinesis / Acoustikinesis (5 each), then the small ones.
- **Per family:** read the family's whole rule section in `build/raw` first: shared rules, Specialties, combinations, "requires", "incompatible". Then check each member and their interactions.
- **Already done:** Magnokinesis, Wall with the Mana Barrier Specialties (Wall side only), the 14 Elementals. Still to do: the Mana Barrier Specialties on Mana Barrier itself, and Tri Elemental Mastery / Arc-en-Ciel (combination immunity rules).

### Phase 6: shared mechanics that entries rely on
Extend `build/test/rules.js`, which has 72 checks so far, with the Base Mechanics that entries point to:
- the Status Effect table (`STATUS` in engine.js vs BaseMechanics pages 77–81: Frigid / Chilled per-part choices, Dazzled's d5 rolls, Petrified, Mindbreak's falling threshold, Mana Burn);
- the once-per-turn Resistance against Elemental Status Effects;
- Physical Status Effects (Silk Hiding Steel), and the rule that imbued attacks can't trigger them;
- rests, Sensitivity chart effects, and item damage and immunity to their own Elemental.

Gaps the earlier phases leave because the shared rule is missing get fixed here.

**Suggested order:** 1 → 2 → 3 → 4 → 5 → 6. Easy tiers first, because they're fast, cover the most entries, and their fixes feed the later tiers. If the user would rather start with the entries they play most, do 5 and 4a first.

## 4. How to check one batch

1. Run `node build/test/check-entry.js` for each entry in the batch. Read the rule text clause by clause, and mark each clause automated / by hand / missing / wrong.
2. Fix what's wrong or missing:
   - Behaviour goes in the entry's record (`build/src/reg/<book>.js`), data in `build/src/data`. The name-check counter must stay at 0.
   - Keep shared code generic: give an entry a `rules` flag rather than naming it in shared code.
   - Then run `node build/build.js`.
3. Test in the sheet:
   - Use the "tests" preview, page `/Fallen%20Heroine%204.5%20CC.html`, driven from JS: `newState()`, `TABS`, `ENC.groups`, `pushIncoming`, `ENC_ACT.incAccept`, `useAbility`, `doCombatRoll`.
   - Clear localStorage afterwards.
   - Check for console errors.
4. Record each entry's verdict in `check-log.json`, and log the batch in `CHANGES-SINCE-CHECK.md` (what changed, what's left as rule text, what wasn't tested).
5. **Rulings:** don't guess when the text allows two readings. Collect them and ask the user in batches (AskUserQuestion, 1–4 questions, recommended option first). Mark the entry `ruling` until answered. Earlier rulings are in HANDOFF.md ("judgement calls", Polarity Cushion and Group Charge, Wall HP = roll total).
6. Don't change unrelated behaviour. If something else turns up, list it as a follow-up.

## 5. Checks, versions, reporting

- **User's rule:** small changes are logged in `CHANGES-SINCE-CHECK.md` without a full check. The full check runs at a version bump or on request:
  - goldens `runAll()`;
  - `interactions()`;
  - `tables()`;
  - `rulesCheck()`.
  
  Then move the log into HANDOFF.md and clear it.
- Goldens compare against v0.4.2 behaviour, so a rules fix can change them. Re-record those scenarios only with a reason: filter, "why" box, `record()`. List the expected interaction and table differences in HANDOFF.md.
- **Versions:** only when the user asks. Ask at the start whether they want one version per phase, as the Item registry plan used.
- After each phase, give the user the counts from `check-groups.js`: checked / fixed / gap / ruling per tier.

## 6. Questions to ask the user at the start
1. One version number per phase, or only when they ask?
2. Order: easiest first (1 → 6), or start with the families / Magic schools they use most?
3. For clauses that need a choice or tracking the sheet doesn't have (body-part choices, GM calls), is "left as rule text, marked gap" acceptable, or should each get a manual prompt?
