// Battle driver for the example encounter. Runs inside the character sheet and uses its own rules engine:
// doCombatRoll (range, modifiers, AP, spell costs), incoming-roll Contest / Accept chains, clothing reach, binding,
// penetration tracking, Sensitivity Rolls, transformation states.
// SIM.setup({heroJSON, extraRavagers, penMax}) → then call SIM.step() until SIM.over.
(function(){
const S=window.SIM={round:0,turns:[],over:null};
const name=s=>tabName(s);
const hero=()=>TABS.find(s=>s.id.type!=="Enemy");
const enemies=()=>TABS.filter(s=>s.id.type==="Enemy");
const calc=s=>{ const p=ST; ST=s; const r=compute(s); ST=p; return r; };
const hpMB=s=>calc(s).hpOf("Main Body");
const alive=s=>s.id.type==="Enemy"?hpMB(s)>0:true;
const as=(s,fn)=>{ ST=s; C=compute(ST); return fn(); };
const LIMBS=["Left Arm","Right Arm","Left Leg","Right Leg"];
function checkOver(){ const b=hero(); const bc=calc(b);
  if(bc.hpOf("Main Body")<=0&&b.cur.pp>=1000) return S.over=name(b)+" is defeated (Main Body 0 HP and "+b.cur.pp+" PP)";
  if(!enemies().some(alive)) return S.over="All enemies are defeated";
  return null; }
// defender answers every pending roll: contest down the chain, accept if all fail
function resolveIncoming(def,ev){
  as(def,()=>{ let guard=0;
    while((ST.incoming||[]).length&&guard++<40){ const p=ST.incoming[0]; C=compute(ST);
      const chain=defenseChain(p,C,ST); const k=chain.length?chain[0][0]:null;
      if(k){ ENC_ACT.incDefend({dataset:{id:p.id,k}}); C=compute(ST); const still=(ST.incoming||[]).some(x=>x.id===p.id);
        const t=ST.roll.lastC?ST.roll.lastC.total:"?";
        if(!still){ ev.push("   ↳ "+name(def)+" contests with "+RNAME[k]+" "+t+" vs "+p.total+": avoided"); continue; }
        ev.push("   ↳ "+name(def)+" "+RNAME[k]+" "+t+" vs "+p.total+": failed"); continue; }
      ENC_ACT.incAccept({dataset:{id:p.id}}); C=compute(ST); ev.push("   ↳ "+name(def)+": "+(ST.log[0]?ST.log[0].body:""));
      ST.prompts=[]; }
  }); }
function roll(actor,target,type,opts,ev){
  return as(actor,()=>{ const R=ST.roll;
    Object.assign(R,{type,vs:target?TAB_ID(target):"",vsGroup:opts.group||"",vsPart:opts.part||"Main Body",vsZone:opts.zone||"P",vsAim:opts.cloth?"cloth":"body",vsClothPart:opts.cloth||"",vsWhole:false,part:opts.using||R.part,sit:0,corr:0,spType:opts.spType||"Single",spMode:"Normal",autoAP:true,autoMM:true,override:false,zone2:"",weapon:opts.weapon||""});
    const before=ST.cur.ap; const prev=R.lastC; doCombatRoll();
    if(R.lastC===prev){ ev.push(name(actor)+": "+(ST.log[0]?ST.log[0].title+(ST.log[0].body?" ("+ST.log[0].body+")":""):"can't act")); ST.cur.ap=Math.max(0,ST.cur.ap-1); return false; }
    const what=type.startsWith("SPELL:")?type.slice(6)+" "+(opts.spType||"Single")+" Combat Spell":RNAME[type];
    const at=opts.group?groupLabel(ENC.groups.find(g=>g.id===opts.group))+" (AOE)":(target?name(target)+"'s ":"")+(opts.cloth?opts.cloth+" clothing":type==="VIO"?"Pussy":opts.part||"Main Body");
    ev.push(name(actor)+" → "+at+": "+what+" d"+(R.lastC.calc.match(/d(\d+)/)||[])[1]+" = "+R.lastC.total+(R.lastC.calc.includes("Top 20%? YES")?" (top 20%)":"")+((R.lastC.calc.match(/(\d+) dmg/)||[])[1]?" · "+R.lastC.calc.match(/(\d+) dmg/)[1]+" dmg":"")+((R.lastC.calc.match(/−(\d+) Mana/)||[])[1]?" · −"+R.lastC.calc.match(/−(\d+) Mana/)[1]+" Mana":""));
    if(ST.cur.ap===before) ST.cur.ap=Math.max(0,ST.cur.ap-1);
    return true; }); }
function moveNear(actor,target,ev){ const tg=groupOf(target), g=groupOf(actor); if(g===tg) return;
  const cost=relOf(g,tg)==="Distant"?2:1; placeIn(actor,tg.id); actor.cur.ap=Math.max(0,actor.cur.ap-cost); ev.push(name(actor)+" moves Near "+name(target)+" (−"+cost+" AP)"); }
function enemyTurn(e,ev){
  const b=hero(); if(!alive(e)) return;
  if(rangeBetween(e,b)!=="Near") moveNear(e,b,ev);
  let n=0;
  while(e.cur.ap>0&&n++<6&&!checkOver()&&alive(e)){
    const bc=calc(b); const nm=e.id.name;
    if(/Snatcher/.test(nm)){ const free=LIMBS.filter(l=>!b.bound[l]); if(free.length) roll(e,b,"GRA",{part:free[0]},ev); else roll(e,b,"ATT",{part:"Main Body"},ev); }
    else if(/Bruiser/.test(nm)){ const free=LIMBS.filter(l=>!b.bound[l]); if(n===1&&free.length) roll(e,b,"GRA",{part:free[free.length-1]},ev); else roll(e,b,"ATT",{part:"Main Body"},ev); }
    else if(/Ravager/.test(nm)){ const cov=bc.cov.parts.Genitalia&&bc.cov.parts.Genitalia.covered;
      if(cov) roll(e,b,"ATT",{cloth:"Genitalia"},ev); else roll(e,b,"VIO",{zone:"P",using:"Cock"},ev); }
    else roll(e,b,"ATT",{part:"Main Body"},ev);
    resolveIncoming(b,ev);
  } }
function bestSpell(h){ const c=calc(h); return (c.spell||[]).slice().sort((a,b)=>b.dmg-a.dmg)[0]||null; }
function heroTurn(ev){
  const b=hero();
  // Henshin: battles start Untransformed — transform first (1 AP, heals, clears penalties)
  if(charNamed(b,"Henshin A Go Go Baby!")&&!isTransformed(b)&&!b.cur.henshinUsed&&formsOf(b).list.length){ as(b,()=>{ const id=formsOf(b).list[0].id; b.cur.henshinUsed=true; b.cur.ap=Math.max(0,b.cur.ap-1); formSwitch(b,id,"−1 AP"); }); ev.push(name(b)+" transforms into "+formName(b)+" (−1 AP)"); }
  // Special Status Effects: one Resistance (or Struggle) Roll per turn above 50 ends them early
  ["Heartache","Stunted","Airhead","Thirsty","Mindbreak"].forEach(sn=>{ if(!b.status.some(x=>x.name===sn)) return; as(b,()=>{ const R=ST.roll, prev=R.lastC, keep=R.type; R.type="RES"; R.vs=""; doCombatRoll(); R.type=keep; if(R.lastC===prev) return; const t=R.lastC.total; if(t>50){ ST.status=ST.status.filter(x=>x.name!==sn); ev.push(name(b)+" Resistance "+t+" > 50: shakes off "+sn); } else ev.push(name(b)+" Resistance "+t+": still suffering "+sn); }); });
  Object.keys(b.bound).filter(l=>b.bound[l]).forEach(l=>{ as(b,()=>{ const str=(ST.boundStr||{})[l]; const prev=ST.roll.lastC; escapeRoll(l); if(ST.roll.lastC!==prev) ev.push(name(b)+" Escape ("+l+") = "+ST.roll.lastC.total+" vs Bound Roll Strength "+str+(ST.bound[l]?": still bound":": freed")); }); });
  let n=0;
  while(b.cur.ap>0&&n++<6&&!checkOver()){
    const foes=enemies().filter(alive); if(!foes.length) break;
    const sp=b.status.some(x=>x.name==="Heartache")?null:bestSpell(b); let done=false;
    if(sp){ // AOE the group with the most enemies when it holds 2+, otherwise single-target the weakest
      encNormalize(); const groups=ENC.groups.map(g=>({g,n:g.members.map(tabOf).filter(s=>s&&s.id.type==="Enemy"&&alive(s)).length,ally:g.members.some(m=>m!==TAB_ID(b)&&tabOf(m)&&tabOf(m).id.type!=="Enemy")})).filter(x=>!x.ally).sort((a,c)=>c.n-a.n);
      const cost=t=>pkCost(sp.tier,t,"Normal",sp.pens);
      if(groups[0]&&groups[0].n>=2&&b.cur.mm>=cost("AOE")){ const g=groups[0].g; const targets=g.members.map(tabOf).filter(s=>s&&s!==b&&alive(s));
        if(roll(b,null,"SPELL:"+sp.tier,{group:g.id,spType:"AOE"},ev)){ targets.forEach(t=>resolveIncoming(t,ev)); done=true; } }
      else if(b.cur.mm>=cost("Single")){ const t=foes.sort((x,y)=>hpMB(x)-hpMB(y))[0]; if(roll(b,t,"SPELL:"+sp.tier,{part:"Main Body",spType:"Single"},ev)){ resolveIncoming(t,ev); done=true; } }
    }
    if(!done){ const near=foes.filter(f=>rangeBetween(b,f)==="Near"); const reach=hasName(b,"Sharpshooter")?foes:near; if(!reach.length){ ev.push(name(b)+" has no enemy in reach and waits"); break; }
      const pool=reach.sort((x,y)=>hpMB(x)-hpMB(y)); const t=pool[0];
      const weps=b.items.filter(i=>i.eq&&!i.dropped&&BYKEY[i.key]&&BYKEY[i.key].n==="Weapon User"); const w=weps.sort((x,y)=>itemEPD(y)-itemEPD(x))[0];
      if(!roll(b,t,"ATT",{part:"Main Body",using:"Right Arm",weapon:w?w.id:""},ev)) break; resolveIncoming(t,ev); }
    enemies().forEach(e=>{ if(!alive(e)&&!e._down){ e._down=1; ev.push("   ★ "+name(e)+" is defeated"); } });
  } }
function endRound(){ TABS.forEach(s=>{ if(s.id.type==="Enemy"&&!alive(s)) return; as(s,()=>endTurn()); }); }
S.setup=function(o={}){
  openSaves(); document.querySelector('[data-a="loadExample"]').click(); TABS=TABS.filter(s=>s.id.name!=="New Character"||s.chars.length);
  encNormalize(); const bat=TABS.find(s=>s.id.name==="Batgirl"); let h=bat;
  if(o.heroJSON){ const g=groupOf(bat); openTab(JSON.parse(JSON.stringify(o.heroJSON)),true); h=ST; TABS=TABS.filter(s=>s!==bat); encNormalize(); placeIn(h,g?ENC.groups.find(x=>x.members.some(m=>tabOf(m)&&tabOf(m).id.name==="Goblin Cutthroat")).id:"new"); }
  // battle-ready: Long Rest values, weapons picked up and equipped, no leftover penetration / binding / prompts
  as(h,()=>{ if(isTransformed(h)) formSwitch(h,"base","Battles start Untransformed"); C=compute(h); ACT.longRest(); h.orgasms=0; h.items.forEach(it=>{ if(it.dropped){ it.dropped=false; it.eq=true; } }); if(o.penMax) h.penMax=o.penMax; h.cur.sensThisTurn=0; });
  const rav=TABS.find(s=>s.id.name==="Orc Ravager");
  for(let i=0;i<(o.extraRavagers??1);i++){ ST=rav; ENC_ACT.tabDup(); }
  encNormalize(); const g2=groupOf(rav); TABS.filter(s=>/Orc Ravager \d/.test(s.id.name)).forEach(s=>placeIn(s,g2.id));
  const sn=TABS.find(s=>s.id.name==="Goblin Snatcher"); for(let i=0;i<(o.extraSnatchers||0);i++){ ST=sn; ENC_ACT.tabDup(); }
  encNormalize(); const g1=groupOf(sn); TABS.filter(s=>/Goblin Snatcher \d/.test(s.id.name)).forEach(s=>placeIn(s,g1.id));
  TABS.forEach(s=>as(s,()=>{ ACT.startBattle(); s.log=[]; s.incoming=[]; s.prompts=[]; }));
  (o.heroStatus||[]).forEach(sn=>{ const h2=hero(); h2.status.push({name:sn,turns:(STATUS[sn]&&STATUS[sn].turns)||3}); });
  ST=hero(); commit();
  const hc=calc(hero());
  return TABS.map(s=>name(s)+" ["+groupLabel(groupOf(s))+"] MB "+hpMB(s)+" AP "+s.cur.ap).join(" | ")+" || "+name(hero())+": "+formName(hero())+" · Mana "+hero().cur.mm+"/"+hc.stats.MM+" · weight "+hc.weight+"/"+hc.stats.WC+" · spells "+JSON.stringify(hc.spell)+" · dice "+hc.dice.ATT+"/EVA "+hc.dice.EVA+"/BAR "+hc.dice.BAR;
};
S.step=function(){
  if(S.over) return S.over;
  S.round++; const ev=[];
  heroTurn(ev);
  if(!checkOver()) enemies().forEach(e=>{ if(!checkOver()) enemyTurn(e,ev); });
  if(!checkOver()) endRound();
  const b=hero(), bc=calc(b);
  const status=name(b)+": Main Body "+bc.hpOf("Main Body")+"/"+bc.maxOf("Main Body")+" · PP "+b.cur.pp+" · SP "+b.cur.sp+" · Mana "+b.cur.mm+" · bound: "+(Object.keys(b.bound).filter(l=>b.bound[l]).join(", ")||"none")+" · Pussy stage "+(b.pen.Pussy|0)+(b.penBy&&b.penBy.Pussy&&(b.pen.Pussy|0)>0?" (by "+b.penBy.Pussy.name+")":"")+" · Genitalia "+(bc.cov.parts.Genitalia.covered?"covered":"exposed")+" · status: "+(b.status.map(x=>x.name+(x.turns?" ("+x.turns+")":"")).join(", ")||"none")+" | Enemies standing: "+enemies().filter(alive).map(e=>name(e)+" "+hpMB(e)).join(", ");
  S.turns.push({round:S.round,ev,status}); ST=b; commit(); checkOver();
  return {round:S.round,ev,status,over:S.over};
};
})();
